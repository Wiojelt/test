version = 2

cloudstream {
    setRepo("https://github.com/Wiojelt/test")
    iconUrl = "https://raw.githubusercontent.com/Wiojelt/test/main/assets/providers/TestDrama.png"
    description = "TestDrama · Movim Short ve DramaBox; türler, Türkçe dublaj ve altyazılı kısa diziler."
    language = "tr"
    status = 1
    authors = listOf("Wiojelt")
    tvTypes = listOf("AsianDrama", "TvSeries")
    requiresResources = false
}
