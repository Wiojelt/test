package dev.wiojelt.testdrama

import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.ExtractorLink
import com.lagradost.cloudstream3.utils.ExtractorLinkType
import com.lagradost.cloudstream3.utils.Qualities
import org.json.JSONObject
import java.net.URLDecoder
import java.net.URLEncoder
import java.text.Normalizer
import java.util.Locale
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class MovimProvider : MainAPI() {
    override var name = "Movim Short"
    override var mainUrl = "https://api.movim.pro"
    override var supportedTypes = setOf(TvType.AsianDrama, TvType.TvSeries)
    override var lang = "tr"
    override val hasMainPage = true
    override val hasQuickSearch = true

    companion object {
        const val MOVIM_UA = "Dalvik/2.1.0 (Linux; U; Android; MssStudio-MSPlayer/1.10.0)"
        const val WEB_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }

    override val mainPage = mainPageOf(
        "new" to "Yeni Eklenen Diziler",
        "popular" to "Popüler Diziler",
        "all" to "Tüm Dikey Diziler",
        "dubbed" to "Türkçe Dublaj", "subbed" to "Türkçe Altyazılı",
        "billionaire" to "Milyarderler ve Patronlar", "revenge" to "İntikam ve Geri Dönüş",
        "family" to "Aile, Çocuklar ve Bebekler", "romance" to "Aşk ve Evlilik",
        "fantasy" to "Alfalar, Kurtlar ve Fantastik Dünyalar", "identity" to "Gizli Kimlik ve Mirasçılar",
        "time" to "Yeniden Doğuş ve İkinci Şans", "power" to "Ustalar, Krallar ve Güç Mücadelesi"
    )

    data class MovimItem(
        val id: String,
        val title: String,
        val subtitle: String,
        val pageName: String,
        val sheetId: String,
        val imageUrl: String
    )

    @Volatile
    private var cachedCatalogue: Pair<Long, List<MovimItem>>? = null
    private val catalogMutex = Mutex()
    private var bootstrapCache: Pair<Long, JSONObject>? = null
    private var firstCursor: String? = null
    private fun normalized(value: String) = Normalizer.normalize(value.lowercase(Locale.forLanguageTag("tr")).replace('ı', 'i'), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")

    private fun parseItem(json: JSONObject): MovimItem? {
        val id = json.optString("id")
        val title = json.optString("title")
        val subtitle = json.optString("subtitle")
        val pageName = json.optString("pageName")
        val sheetId = json.optString("sheetId")
        val imageUrl = json.optString("imageUrl")
        if (id.isBlank() && pageName.isBlank()) return null
        return MovimItem(id, title, subtitle, pageName, sheetId, imageUrl)
    }

    private suspend fun fetchBootstrap(): Triple<List<MovimItem>, List<MovimItem>, List<MovimItem>> {
        val root = bootstrapCache?.takeIf { System.currentTimeMillis() - it.first < 120_000 }?.second ?: run {
            val response = runCatching {
                app.get("$mainUrl/v1/bootstrap", headers = mapOf("User-Agent" to MOVIM_UA), timeout = 15).text
            }.getOrNull() ?: return Triple(emptyList(), emptyList(), emptyList())
            JSONObject(response).also { bootstrapCache = System.currentTimeMillis() to it }
        }
        val newArr = root.optJSONArray("new") ?: org.json.JSONArray()
        val popArr = root.optJSONArray("popular") ?: org.json.JSONArray()
        val allObj = root.optJSONObject("all")
        val allArr = allObj?.optJSONArray("items") ?: org.json.JSONArray()
        firstCursor = if (allObj?.optBoolean("hasMore", false) == true) allObj.optString("nextCursor").takeIf { it.isNotBlank() } else null

        val newList = (0 until newArr.length()).mapNotNull { parseItem(newArr.getJSONObject(it)) }
        val popList = (0 until popArr.length()).mapNotNull { parseItem(popArr.getJSONObject(it)) }
        val allList = (0 until allArr.length()).mapNotNull { parseItem(allArr.getJSONObject(it)) }

        return Triple(newList, popList, allList)
    }

    private suspend fun loadAllCatalogue(): List<MovimItem> = catalogMutex.withLock {
        val cached = cachedCatalogue
        val now = System.currentTimeMillis()
        if (cached != null && now - cached.first < 15 * 60 * 1000L) {
            return@withLock cached.second
        }

        val allItems = mutableListOf<MovimItem>()
        val (newList, popList, allList) = fetchBootstrap()
        allItems.addAll(newList)
        allItems.addAll(popList)
        allItems.addAll(allList)

        var cursor: String? = firstCursor
        val visited = mutableSetOf<String>()
        var iterations = 0
        while (!cursor.isNullOrBlank() && iterations < 100 && visited.add(cursor)) {
            iterations++
            val pageResp = runCatching {
                val url = "$mainUrl/v1/series?cursor=${URLEncoder.encode(cursor, "UTF-8")}&limit=60"
                app.get(url, headers = mapOf("User-Agent" to MOVIM_UA), timeout = 15).text
            }.getOrNull() ?: break

            val root = JSONObject(pageResp)
            val itemsArr = root.optJSONArray("items") ?: break
            val count = itemsArr.length()
            if (count == 0) break

            for (i in 0 until count) {
                parseItem(itemsArr.getJSONObject(i))?.let { allItems.add(it) }
            }

            val hasMore = root.optBoolean("hasMore", false)
            cursor = if (hasMore) root.optString("nextCursor") else null
        }

        val distinct = allItems.distinctBy { "${it.sheetId}:${it.pageName}".takeIf { key -> key != ":" } ?: it.id }
        cachedCatalogue = Pair(now, distinct)
        distinct
    }

    private fun toSearchResponse(item: MovimItem): SearchResponse {
        val displayTitle = if (item.subtitle.isNotBlank()) "${item.title} (${item.subtitle})" else item.title
        val encodedUrl = "$mainUrl/series/${item.id}?sheetId=${URLEncoder.encode(item.sheetId, "UTF-8")}&pageName=${URLEncoder.encode(item.pageName, "UTF-8")}&title=${URLEncoder.encode(item.title, "UTF-8")}&image=${URLEncoder.encode(item.imageUrl, "UTF-8")}"
        return newTvSeriesSearchResponse(displayTitle, encodedUrl, TvType.AsianDrama) {
            this.posterUrl = item.imageUrl
        }
    }

    override suspend fun getMainPage(page: Int, request: MainPageRequest): HomePageResponse {
        val (newList, popList, _) = fetchBootstrap()
        val catalogue = when (request.data) {
            "new" -> newList
            "popular" -> popList
            else -> {
                val all = loadAllCatalogue()
                val words = when (request.data) {
                    "billionaire" -> listOf("milyarder", "patron", "ceo", "zengin")
                    "revenge" -> listOf("intikam", "pisman", "ihanet", "geri don", "kaybet", "terk")
                    "family" -> listOf("bebek", "cocuk", "aile", "anne", "baba", "ogul", "kizim", "ucuz", "ikiz")
                    "romance" -> listOf("ask", "evli", "evlen", "koca", "karim", "gelin", "nisan", "sevgil")
                    "fantasy" -> listOf("alfa", "kurt", "luna", "fantastik", "ejderha", "vampir")
                    "identity" -> listOf("gizli", "kimlik", "varis", "miras", "gercek")
                    "time" -> listOf("yeniden", "ikinci", "dogus", "zaman", "gecmis")
                    "power" -> listOf("usta", "kral", "guclu", "guclen", "savas", "hekim", "tanri")
                    else -> emptyList()
                }
                all.filter { item ->
                    when (request.data) {
                        "dubbed" -> normalized(item.subtitle).contains("dublaj")
                        "subbed" -> normalized(item.subtitle).contains("altyazi")
                        else -> words.isEmpty() || words.any { normalized(item.title).contains(it) }
                    }
                }
            }
        }
        val offset = (page.coerceAtLeast(1) - 1) * 30
        val items = catalogue.drop(offset).take(30).map(::toSearchResponse)
        return newHomePageResponse(request.name, items, hasNext = offset + items.size < catalogue.size)
    }

    override suspend fun search(query: String): List<SearchResponse> {
        val q = normalized(query.trim())
        if (q.isBlank()) return emptyList()
        val all = loadAllCatalogue()
        return all.filter {
            normalized(it.title).contains(q) || normalized(it.subtitle).contains(q) || normalized(it.pageName).contains(q)
        }.map { toSearchResponse(it) }
    }

    override suspend fun quickSearch(query: String): List<SearchResponse> = search(query)

    private fun parseCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        var inQuotes = false
        val sb = StringBuilder()
        for (ch in line) {
            if (ch == '\"') {
                inQuotes = !inQuotes
            } else if (ch == ',' && !inQuotes) {
                result.add(sb.toString().trim())
                sb.clear()
            } else {
                sb.append(ch)
            }
        }
        result.add(sb.toString().trim())
        return result
    }

    override suspend fun load(url: String): LoadResponse? {
        val params = url.substringAfter("?").split("&").associate {
            val kv = it.split("=", limit = 2)
            val k = kv.getOrNull(0) ?: ""
            val v = kv.getOrNull(1) ?: ""
            k to URLDecoder.decode(v, "UTF-8")
        }

        val sheetId = params["sheetId"] ?: ""
        val pageName = params["pageName"] ?: ""
        val title = params["title"] ?: "Movim Dizi"
        val image = params["image"] ?: ""

        // Eğer sheetId boş ise doğrudan video linkidir (örn. tekil film)
        if (sheetId.isBlank() && pageName.startsWith("http")) {
            return newMovieLoadResponse(title, url, TvType.Movie, pageName) {
                this.posterUrl = image
            }
        }

        if (sheetId.isBlank() || pageName.isBlank()) return null

        val gvizUrl = "https://docs.google.com/spreadsheets/d/$sheetId/gviz/tq?tqx=out:csv&range=A:B&sheet=${URLEncoder.encode(pageName, "UTF-8")}"
        val csvText = runCatching {
            app.get(gvizUrl, headers = mapOf("User-Agent" to WEB_UA), timeout = 15).text
        }.getOrNull() ?: return null

        val episodes = mutableListOf<Episode>()
        val lines = csvText.lines()
        var epIndex = 1
        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.isBlank()) continue
            val parts = parseCsvLine(trimmed)
            if (parts.size >= 2) {
                val epName = parts[0].trim().removeSurrounding("\"")
                val streamUrl = parts[1].trim().removeSurrounding("\"")
                if (streamUrl.startsWith("http")) {
                    episodes.add(
                        newEpisode(streamUrl) {
                            this.name = epName.ifBlank { "Bölüm $epIndex" }
                            this.episode = epIndex
                            this.season = 1
                        }
                    )
                    epIndex++
                }
            }
        }

        if (episodes.isEmpty()) return null

        return newTvSeriesLoadResponse(title, url, TvType.AsianDrama, episodes) {
            this.posterUrl = image
            this.plot = "$title - Movim Short Türkçe Dizi (${episodes.size} Bölüm)"
        }
    }

    override suspend fun loadLinks(
        data: String,
        isCasting: Boolean,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val isM3u8 = data.contains(".m3u8")
        callback(
            ExtractorLink(
                source = name,
                name = name,
                url = data,
                referer = "https://api.movim.pro/",
                quality = Qualities.Unknown.value,
                type = if (isM3u8) ExtractorLinkType.M3U8 else ExtractorLinkType.VIDEO,
                headers = mapOf(
                    "User-Agent" to MOVIM_UA,
                    "Referer" to "https://api.movim.pro/"
                )
            )
        )
        return true
    }
}
