package dev.wiojelt.testdrama

import android.content.Context
import com.lagradost.cloudstream3.plugins.CloudstreamPlugin
import com.lagradost.cloudstream3.plugins.Plugin

@CloudstreamPlugin
class TestDramaPlugin : Plugin() {
    override fun load(context: Context) {
        registerMainAPI(MovimProvider())
        registerMainAPI(DramaBoxProvider())
    }
}
