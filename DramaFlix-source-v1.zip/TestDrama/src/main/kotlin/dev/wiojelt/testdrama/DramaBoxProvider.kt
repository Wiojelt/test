package dev.wiojelt.testdrama

import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.ExtractorLink
import com.lagradost.cloudstream3.utils.ExtractorLinkType
import com.lagradost.cloudstream3.utils.Qualities
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

class DramaBoxProvider : MainAPI() {
    override var name = "DramaBox"
    override var mainUrl = "https://www.dramabox.com"
    override var supportedTypes = setOf(TvType.AsianDrama, TvType.TvSeries)
    override var lang = "tr"
    override val hasMainPage = true
    override val hasQuickSearch = true

    companion object {
        const val DRAMA_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        private val NEXT_DATA_REGEX = Regex("""<script id="__NEXT_DATA__"[^>]*>(.*?)</script>""", RegexOption.DOT_MATCHES_ALL)
    }

    override val mainPage = mainPageOf(
        "recommend" to "Öne Çıkanlar", "hot" to "Popüler Dikey Dramalar",
        "browse:0" to "Tüm Diziler", "browse:10104" to "Yasak Aşk", "browse:10068" to "Evlilik Aşkı",
        "browse:10105" to "Aşk Üçgeni", "browse:10187" to "Aile Bağı", "browse:10088" to "Kurtadam",
        "browse:10177" to "Reenkarnasyon", "browse:10200" to "Fantastik", "browse:10090" to "Vampir",
        "browse:10169" to "Kader Aşkı", "browse:10175" to "Ofis Aşkı", "browse:10087" to "CEO",
        "browse:10070" to "Gizli Kimlik", "browse:10178" to "Düşmandan Aşka", "browse:10189" to "Sevimli Bebek",
        "browse:10182" to "Zamanda Yolculuk", "browse:10100" to "Kariyer Kadını", "browse:10198" to "Sporcu"
    )

    private fun extractNextProps(html: String): JSONObject? {
        val match = NEXT_DATA_REGEX.find(html) ?: return null
        val jsonStr = match.groupValues.getOrNull(1) ?: return null
        return runCatching {
            JSONObject(jsonStr).optJSONObject("props")?.optJSONObject("pageProps")
        }.getOrNull()
    }

    override suspend fun getMainPage(page: Int, request: MainPageRequest): HomePageResponse {
        if (request.data.startsWith("browse:")) {
            val props = extractNextProps(app.get("$mainUrl/tr/browse/${request.data.substringAfter(':')}/${page.coerceAtLeast(1)}", headers = mapOf("User-Agent" to DRAMA_UA), timeout = 20).text)
                ?: return newHomePageResponse(request.name, emptyList(), false)
            val books = props.optJSONArray("bookList") ?: JSONArray()
            val items = (0 until books.length()).mapNotNull {
                val book = books.optJSONObject(it) ?: return@mapNotNull null
                val id = book.optString("bookId")
                val title = book.optString("bookName")
                if (id.isBlank() || title.isBlank()) return@mapNotNull null
                newTvSeriesSearchResponse(title, "$mainUrl/tr/video/$id", TvType.AsianDrama) { posterUrl = book.optString("cover") }
            }
            return newHomePageResponse(request.name, items, props.optInt("pageNo", page) < props.optInt("pages", page))
        }
        if (page > 1) return newHomePageResponse(request.name, emptyList(), false)
        val html = runCatching {
            app.get(
                "$mainUrl/tr",
                headers = mapOf(
                    "User-Agent" to DRAMA_UA,
                    "Accept-Language" to "tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7"
                ),
                timeout = 15
            ).text
        }.getOrNull() ?: return newHomePageResponse(request.name, emptyList(), false)

        val props = extractNextProps(html) ?: return newHomePageResponse(request.name, emptyList(), false)
        val items = mutableListOf<SearchResponse>()

        if (request.data == "recommend") {
            val bigList = props.optJSONArray("bigList") ?: JSONArray()
            for (i in 0 until bigList.length()) {
                val book = bigList.getJSONObject(i)
                val bookId = book.optString("bookId")
                val bookName = book.optString("bookName")
                val cover = book.optString("cover").ifBlank { book.optString("coverWap") }
                if (bookId.isNotBlank() && bookName.isNotBlank()) {
                    items.add(
                        newTvSeriesSearchResponse(bookName, "$mainUrl/tr/video/$bookId", TvType.AsianDrama) {
                            this.posterUrl = cover
                        }
                    )
                }
            }
        } else {
            val smallData = props.optJSONArray("smallData") ?: JSONArray()
            for (i in 0 until smallData.length()) {
                val cat = smallData.getJSONObject(i)
                val catItems = cat.optJSONArray("items") ?: JSONArray()
                for (j in 0 until catItems.length()) {
                    val book = catItems.getJSONObject(j)
                    val bookId = book.optString("bookId")
                    val bookName = book.optString("bookName")
                    val cover = book.optString("cover").ifBlank { book.optString("coverWap") }
                    if (bookId.isNotBlank() && bookName.isNotBlank()) {
                        items.add(
                            newTvSeriesSearchResponse(bookName, "$mainUrl/tr/video/$bookId", TvType.AsianDrama) {
                                this.posterUrl = cover
                            }
                        )
                    }
                }
            }
        }

        val distinct = items.distinctBy { it.url }
        return newHomePageResponse(request.name, distinct, false)
    }

    override suspend fun search(query: String): List<SearchResponse> {
        val q = query.trim()
        if (q.isBlank()) return emptyList()

        val searchUrl = "$mainUrl/tr/search?keyword=${URLEncoder.encode(q, "UTF-8")}"
        val html = runCatching {
            app.get(
                searchUrl,
                headers = mapOf("User-Agent" to DRAMA_UA),
                timeout = 15
            ).text
        }.getOrNull() ?: return emptyList()

        val props = extractNextProps(html) ?: return emptyList()
        val items = mutableListOf<SearchResponse>()

        fun addList(arr: JSONArray?) {
            if (arr == null) return
            for (i in 0 until arr.length()) {
                val book = arr.getJSONObject(i)
                val bookId = book.optString("bookId")
                val bookName = book.optString("bookName")
                val cover = book.optString("cover").ifBlank {
                    book.optString("coverWap").ifBlank { book.optString("coverCutWap") }
                }
                if (bookId.isNotBlank() && bookName.isNotBlank()) {
                    items.add(
                        newTvSeriesSearchResponse(bookName, "$mainUrl/tr/video/$bookId", TvType.AsianDrama) {
                            this.posterUrl = cover
                        }
                    )
                }
            }
        }

        addList(props.optJSONArray("bookList"))
        addList(props.optJSONArray("similarList"))

        return items.distinctBy { it.url }
    }

    override suspend fun quickSearch(query: String): List<SearchResponse> = search(query)

    override suspend fun load(url: String): LoadResponse? {
        val html = runCatching {
            app.get(
                url,
                headers = mapOf(
                    "User-Agent" to DRAMA_UA,
                    "Referer" to "$mainUrl/"
                ),
                timeout = 15
            ).text
        }.getOrNull() ?: return null

        val props = extractNextProps(html) ?: return null
        val bookInfo = props.optJSONObject("bookInfo") ?: JSONObject()
        val title = bookInfo.optString("bookName").ifBlank { "DramaBox Dizi" }
        val cover = bookInfo.optString("cover")
        val plot = bookInfo.optString("introduction")

        val chapterList = props.optJSONArray("chapterList") ?: JSONArray()
        val episodes = mutableListOf<Episode>()

        for (i in 0 until chapterList.length()) {
            val ch = chapterList.getJSONObject(i)
            val chapterId = ch.optString("id")
            if (chapterId.isNotBlank()) {
                val chName = ch.optString("name")
                val index = ch.optInt("index", i) + 1
                val chCover = ch.optString("cover")
                episodes.add(
                    newEpisode(JSONObject().put("page", "$mainUrl/tr/video/${bookInfo.optString("bookId")}_${URLEncoder.encode(bookInfo.optString("bookNameEn"), "UTF-8")}/${chapterId}_Episode-$index").put("chapterId", chapterId).toString()) {
                        this.name = "Bölüm $index"
                        this.episode = index
                        this.season = 1
                        this.posterUrl = chCover
                    }
                )
            }
        }

        if (episodes.isEmpty()) return null

        return newTvSeriesLoadResponse(title, url, TvType.AsianDrama, episodes) {
            this.posterUrl = cover
            this.plot = plot.ifBlank { "$title - DramaBox Dikey Kısa Dizi" } + "\n\nBölümler oynatılırken güncel video adresi alınır. Sadece kısa önizleme sunulan bölümler tam video yerine oynatılmaz."
        }
    }

    override suspend fun loadLinks(
        data: String,
        isCasting: Boolean,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        if (data.startsWith("http")) throw ErrorLoadingException("Video adresini yenilemek için dizi sayfasını yeniden aç.")
        val payload = JSONObject(data)
        val pageUrl = payload.getString("page")
        val props = extractNextProps(app.get(pageUrl, headers = mapOf("User-Agent" to DRAMA_UA), timeout = 20).text) ?: return false
        val chapters = props.optJSONArray("chapterList") ?: return false
        val chapter = (0 until chapters.length()).mapNotNull { chapters.optJSONObject(it) }.firstOrNull { it.optString("id") == payload.getString("chapterId") } ?: return false
        val stream = chapter.optString("mp4").ifBlank {
            props.optString("freeSource").takeUnless { it.contains("15s", true) || it.contains("preview", true) }.orEmpty()
        }
        if (!stream.startsWith("https://")) throw ErrorLoadingException("DramaBox bu bölümde yalnızca önizleme veya uygulama erişimi sunuyor; tam video bağlantısı yok.")
        val hls = chapter.optBoolean("m3u8Flag") || stream.substringBefore('?').endsWith(".m3u8")
        val resolution = Regex("\\.(\\d{3,4})p[.]").find(stream)?.groupValues?.get(1)?.toIntOrNull() ?: Qualities.Unknown.value
        callback(
            ExtractorLink(
                source = name,
                name = name,
                url = stream,
                referer = pageUrl,
                quality = resolution,
                type = if (hls) ExtractorLinkType.M3U8 else ExtractorLinkType.VIDEO,
                headers = mapOf(
                    "User-Agent" to DRAMA_UA,
                    "Referer" to pageUrl
                )
            )
        )
        return true
    }
}
