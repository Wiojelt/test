version = 1

cloudstream {
    setRepo("https://github.com/Wiojelt/test")
    iconUrl = "https://raw.githubusercontent.com/Wiojelt/test/main/assets/providers/DramaFlix.png"
    description = "DramaFlix · Türkçe kısa diziler, platformlar, türler, dublaj, altyazı ve hesap girişi."
    language = "tr"
    status = 1
    authors = listOf("Wiojelt")
    tvTypes = listOf("AsianDrama", "TvSeries")
    requiresResources = false
}
