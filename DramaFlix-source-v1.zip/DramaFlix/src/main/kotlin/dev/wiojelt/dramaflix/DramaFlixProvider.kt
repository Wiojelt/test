package dev.wiojelt.dramaflix

import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.ExtractorLink
import com.lagradost.cloudstream3.utils.ExtractorLinkType
import com.lagradost.cloudstream3.utils.Qualities
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale

class DramaFlixProvider(private val session: DramaFlixSession) : MainAPI() {
    override var name = "DramaFlix"
    override var mainUrl = "https://dramaflix.net"
    override var lang = "tr"
    override var supportedTypes = setOf(TvType.AsianDrama, TvType.TvSeries)
    override val hasMainPage = true
    override val hasQuickSearch = true

    override val mainPage = mainPageOf(
        "home:hero" to "Öne Çıkanlar", "home:must_watch" to "Bu Hafta İzle",
        "sort=popular" to "Popüler Diziler", "sort=trending_week" to "Bu Hafta En Çok İzlenenler",
        "sort=trending_month" to "Bu Ay En Çok İzlenenler", "sort=newest" to "Yeni Eklenenler",
        "dubbed=1" to "Türkçe Dublajlı",
        "tag=i-ntikam" to "İntikam", "tag=modern" to "Modern Dramalar",
        "tag=gizli-kimlik" to "Gizli Kimlik", "tag=yukselis" to "Yükseliş",
        "tag=hesap-sorma" to "Hesap Sorma", "tag=yuksek-sosyete" to "Yüksek Sosyete",
        "tag=rol-degisimi" to "Rol Değişimi", "tag=aile-baglari" to "Aile Bağları",
        "tag=i-kinci-sans" to "İkinci Şans", "tag=romantik" to "Romantik",
        "tag=calkantili-ask" to "Çalkantılı Aşk", "tag=ask-ucgeni" to "Aşk Üçgeni",
        "platform=PineDrama" to "PineDrama", "platform=FreeReels" to "FreeReels",
        "platform=DramaWave" to "DramaWave", "platform=NetShort" to "NetShort",
        "platform=ReelShort" to "ReelShort", "platform=FlexTV" to "FlexTV",
        "platform=ShortMax" to "ShortMax", "platform=Storyreel" to "Storyreel",
        "platform=MoboReels" to "MoboReels", "platform=DramaBox" to "DramaBox",
        "platform=VibeShort" to "VibeShort", "platform=MeloShort" to "MeloShort"
    )

    private var homeCache: Pair<Long, JSONObject>? = null
    private fun encode(value: String) = URLEncoder.encode(value, "UTF-8")
    private fun absolute(value: String) = if (value.startsWith("/")) mainUrl + value else value
    private fun JSONArray.objects() = (0 until length()).mapNotNull { optJSONObject(it) }
    private fun JSONObject.text(key: String) = optString(key).takeUnless { it == "null" }.orEmpty()
    private suspend fun json(path: String): JSONObject {
        val response = app.get(mainUrl + path, headers = session.headers(mainUrl), timeout = 20)
        if (response.code == 403 || response.code == 401) {
            val detail = runCatching { JSONObject(response.text).text("detail") }.getOrDefault("")
            if (detail == "vip_required") throw ErrorLoadingException("Bu bölüm DramaFlix üyeliği istiyor. Eklenti ayarlarından hesabına giriş yap.")
            throw ErrorLoadingException("DramaFlix erişimi doğrulanamadı. Eklenti ayarlarından siteyi açıp girişini kontrol et.")
        }
        if (response.code != 200) throw ErrorLoadingException("DramaFlix yanıt vermedi (${response.code}).")
        return JSONObject(response.text)
    }
    private suspend fun cachedHome(): JSONObject {
        homeCache?.takeIf { System.currentTimeMillis() - it.first < 120_000 }?.let { return it.second }
        return json("/api/home?language=TR").also { homeCache = System.currentTimeMillis() to it }
    }
    private fun card(item: JSONObject): SearchResponse? {
        val slug = item.text("slug")
        val title = item.text("title")
        if (slug.isBlank() || title.isBlank()) return null
        return newTvSeriesSearchResponse(title, "$mainUrl/tr/drama/$slug", TvType.AsianDrama) {
            posterUrl = absolute(item.text("cover_image").ifBlank { item.text("cover") })
        }
    }
    private fun cards(items: JSONArray?) = items?.objects()?.mapNotNull(::card)?.distinctBy { it.url }.orEmpty()
    private suspend fun series(query: String, page: Int): Pair<List<SearchResponse>, Boolean> {
        val offset = (page.coerceAtLeast(1) - 1) * 30
        val filter = if (query.startsWith("tag=")) query.replaceFirst("tag=", "genre=") else query
        val root = json("/api/series?language=TR&limit=30&offset=$offset&$filter")
        val list = cards(root.optJSONArray("series"))
        return list to (offset + list.size < root.optInt("total", offset + list.size))
    }
    override suspend fun getMainPage(page: Int, request: MainPageRequest): HomePageResponse {
        if (request.data.startsWith("home:")) {
            return newHomePageResponse(request.name, if (page == 1) cards(cachedHome().optJSONArray(request.data.substringAfter(':'))) else emptyList(), false)
        }
        val (items, more) = series(request.data, page)
        return newHomePageResponse(request.name, items, more)
    }
    override suspend fun search(query: String) = series("search=${encode(query.trim())}", 1).first
    override suspend fun quickSearch(query: String) = search(query)

    override suspend fun load(url: String): LoadResponse {
        val slug = url.substringBefore('?').trimEnd('/').substringAfterLast('/')
        val root = json("/api/series/${encode(slug)}")
        val info = root.getJSONObject("series")
        val episodes = root.optJSONArray("episodes")?.objects().orEmpty().map { ep ->
            val number = ep.optInt("episode_number")
            val payload = JSONObject().put("id", ep.getLong("id")).put("slug", slug).put("number", number)
            newEpisode(payload.toString()) {
                episode = number
                season = 1
                name = ep.text("title").ifBlank { "$number. Bölüm" }
                posterUrl = absolute(ep.text("thumbnail"))
            }
        }.sortedBy { it.episode }
        if (episodes.isEmpty()) throw ErrorLoadingException("Bu dizinin bölümleri henüz yayınlanmamış.")
        val limit = root.optJSONObject("access")?.optInt("free_episode_limit", 15) ?: 15
        val title = info.text("title")
        return newTvSeriesLoadResponse(title, url, TvType.AsianDrama, episodes) {
            posterUrl = absolute(info.text("cover_image"))
            backgroundPosterUrl = absolute(info.text("backdrop_image"))
            plot = listOf(info.text("description"), "İlk $limit bölüm ücretsizdir. Üyelik isteyen bölümler için eklenti ayarlarından DramaFlix hesabına giriş yap.",
                if (info.optBoolean("ongoing")) "Dizi devam ediyor; yeni bölümler yayınlandıkça eklenir." else "").filter { it.isNotBlank() }.joinToString("\n\n")
            tags = listOf(info.text("platform"), info.text("genre")) + info.optJSONArray("tags")?.objects().orEmpty().map { it.text("name") }
        }
    }
    override suspend fun loadLinks(data: String, isCasting: Boolean, subtitleCallback: (SubtitleFile) -> Unit, callback: (ExtractorLink) -> Unit): Boolean {
        val ep = JSONObject(data)
        val response = json("/api/stream/${ep.getLong("id")}?locale=tr")
        val url = absolute(response.text("url"))
        if (!url.startsWith("https://")) return false
        val referer = "$mainUrl/tr/drama/${ep.text("slug")}/bolum-${ep.optInt("number")}" 
        val headers = session.mediaHeaders(url, referer)
        val hls = response.text("type") == "hls" || url.substringBefore('?').endsWith(".m3u8")
        if (hls) {
            val manifest = app.get(url, headers = headers, timeout = 20)
            if (manifest.code != 200 || !manifest.text.trimStart().startsWith("#EXTM3U")) throw ErrorLoadingException("DramaFlix video yayını henüz hazır değil. Yeniden dene.")
        }
        response.optJSONArray("subtitles")?.objects().orEmpty().distinctBy { it.text("url") }.forEach {
            val sub = absolute(it.text("url"))
            if (sub.startsWith("https://")) {
                val code = it.text("lang").ifBlank { it.text("language") }.lowercase(Locale.ROOT)
                val label = when (code) { "tr", "tr-tr" -> "Türkçe"; "en", "en-us" -> "İngilizce"; else -> it.text("label").ifBlank { code } }
                subtitleCallback(newSubtitleFile(label, sub) { this.headers = session.mediaHeaders(sub, referer) })
            }
        }
        callback(ExtractorLink(name, name, url, referer, Qualities.Unknown.value, headers = headers,
            type = if (hls) ExtractorLinkType.M3U8 else ExtractorLinkType.VIDEO))
        return true
    }
}
