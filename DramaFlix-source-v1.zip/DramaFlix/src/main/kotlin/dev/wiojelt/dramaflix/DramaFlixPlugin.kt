package dev.wiojelt.dramaflix

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import com.lagradost.cloudstream3.plugins.CloudstreamPlugin
import com.lagradost.cloudstream3.plugins.Plugin
import org.json.JSONArray
import java.net.URI

class DramaFlixSession(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("dramaflix_session", Context.MODE_PRIVATE)
    val userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    fun headers(origin: String): Map<String, String> = buildMap {
        put("User-Agent", userAgent)
        put("Referer", "$origin/tr/")
        if (!prefs.getBoolean("signedOut", false)) {
            prefs.getString("token", null)?.takeIf { it.isNotBlank() }?.let { put("Authorization", "Bearer $it") }
            CookieManager.getInstance().getCookie(origin)?.takeIf { it.isNotBlank() }?.let { put("Cookie", it) }
        }
    }
    fun mediaHeaders(url: String, referer: String): Map<String, String> = buildMap {
        put("User-Agent", userAgent)
        put("Referer", referer)
        // A login token must never be forwarded to a third-party CDN.
        if (!prefs.getBoolean("signedOut", false) && runCatching { URI(url).host == "dramaflix.net" }.getOrDefault(false)) {
            CookieManager.getInstance().getCookie(url)?.takeIf { it.isNotBlank() }?.let { put("Cookie", it) }
        }
    }
    @SuppressLint("SetJavaScriptEnabled")
    fun show(context: Context) {
        AlertDialog.Builder(context).setTitle("DramaFlix hesabı")
            .setItems(arrayOf("Siteyi aç / hesaba giriş yap", "Oturumu kapat")) { _, which ->
                if (which == 0) login(context) else {
                    prefs.edit().clear().putBoolean("signedOut", true).apply()
                    Toast.makeText(context, "Eklentideki DramaFlix oturumu kapatıldı.", Toast.LENGTH_SHORT).show()
                }
            }.setNegativeButton("Kapat", null).show()
    }
    @SuppressLint("SetJavaScriptEnabled")
    private fun login(context: Context) {
        prefs.edit().putBoolean("signedOut", false).apply()
        val web = WebView(context)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.userAgentString = userAgent
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false)
        val dialog = AlertDialog.Builder(context).setTitle("DramaFlix · Giriş")
            .setView(web).setPositiveButton("Tamam", null).create()
        val handler = Handler(Looper.getMainLooper())
        var closed = false
        val poll = object : Runnable {
            override fun run() {
                if (closed) return
                if (runCatching { URI(web.url.orEmpty()).host == "dramaflix.net" }.getOrDefault(false)) {
                    web.evaluateJavascript("(function(){return localStorage.getItem('token')||''})()") { value ->
                        if (!closed) runCatching {
                            val token = JSONArray("[$value]").optString(0)
                            if (token.isNotBlank() && token != "null") prefs.edit().putString("token", token).apply()
                        }
                    }
                }
                handler.postDelayed(this, 2000)
            }
        }
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) { CookieManager.getInstance().flush() }
        }
        dialog.setOnDismissListener {
            closed = true
            handler.removeCallbacks(poll)
            web.stopLoading()
            web.destroy()
        }
        dialog.show()
        web.loadUrl("https://dramaflix.net/login")
        handler.post(poll)
    }
}

@CloudstreamPlugin
class DramaFlixPlugin : Plugin() {
    override fun load(context: Context) {
        val session = DramaFlixSession(context)
        registerMainAPI(DramaFlixProvider(session))
        openSettings = { ui -> session.show(ui) }
    }
}
