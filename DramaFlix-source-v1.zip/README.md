# DramaFlix v1

CloudStream kaynak kodu. Android SDK konumunu local.properties dosyasına ekleyin.

Build: `gradlew :DramaFlix:make`

DramaFlix hesap girişi eklenti ayarlarında yapılır. Oturum yalnızca cihazda saklanır.
Gerçek CloudStream oynatımı ve ücretli hesap oturumu cihazda doğrulanmamıştır.
