package dev.wiojelt.turksinema.common

import android.content.Context
import android.provider.Settings
import java.net.HttpURLConnection
import java.net.URI
import java.util.UUID
import kotlin.concurrent.thread

object WioTelemetry {
    private const val PREFS = "wio_telemetry_prefs"
    private const val KEY_LAST_PING = "last_telemetry_ping"
    private const val KEY_DEV_ID = "wio_telemetry_device_id"
    private const val PING_INTERVAL_MS = 4 * 60 * 60 * 1000L // 4 saat yerel filtre

    fun ping(context: Context, appName: String = "WioSinema", version: String = "1.0") {
        try {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val now = System.currentTimeMillis()
            val lastPing = prefs.getLong("${KEY_LAST_PING}_$appName", 0L)
            if (now - lastPing < PING_INTERVAL_MS) return

            thread(name = "WioTelemetryPing", isDaemon = true) {
                try {
                    var deviceId = try {
                        Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
                    } catch (_: Throwable) { null }

                    if (deviceId.isNullOrBlank()) {
                        deviceId = prefs.getString(KEY_DEV_ID, null) ?: UUID.randomUUID().toString().replace("-", "").also {
                            prefs.edit().putString(KEY_DEV_ID, it).apply()
                        }
                    }

                    val urlStr = "https://wiojelt-auth.hdf-worker.workers.dev/api/telemetry?app=$appName&deviceId=$deviceId&v=$version"
                    val conn = (URI(urlStr).toURL().openConnection() as HttpURLConnection).apply {
                        connectTimeout = 4000
                        readTimeout = 4000
                        setRequestProperty("User-Agent", "CloudStream/3.0")
                    }
                    val code = conn.responseCode
                    conn.disconnect()
                    if (code in 200..299) {
                        prefs.edit().putLong("${KEY_LAST_PING}_$appName", now).apply()
                    }
                } catch (_: Throwable) {
                    // Sessizce yutulur
                }
            }
        } catch (_: Throwable) {}
    }
}
