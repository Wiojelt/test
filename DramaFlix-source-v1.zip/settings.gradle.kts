pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS); repositories { google(); mavenCentral(); maven("https://jitpack.io") } }
plugins { id("org.gradle.toolchains.foojay-resolver-convention") version "1.0.0" }
rootProject.name = "ShortDramaProviders"
includeBuild(".build-tools/cloudstream-gradle") { name = "cloudstream-build-tool"; dependencySubstitution { substitute(module("com.github.recloudstream.gradle:gradle")).using(project(":")) } }
include("DramaFlix", "TestDrama")
