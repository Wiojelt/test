version = 2

cloudstream {
    language = "tr"
    description = "TurkStream test sağlayıcısı; katalog doğrulandı, oynatıcı akışı siteye göre beklemede olabilir."
    status = 3
    tvTypes = listOf("Movie", "TvSeries")
    iconUrl = "https://www.hdfilmizle.best/wp-content/themes/hdfilmizle/assets/img/apple-touch-icon.png?v=3.9.190"
}
