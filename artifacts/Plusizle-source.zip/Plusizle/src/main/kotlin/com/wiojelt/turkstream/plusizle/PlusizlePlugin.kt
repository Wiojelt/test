package com.wiojelt.turkstream.plusizle

import android.content.Context
import com.lagradost.cloudstream3.plugins.CloudstreamPlugin
import com.lagradost.cloudstream3.plugins.Plugin

@CloudstreamPlugin
class PlusizlePlugin : Plugin() {
    override fun load(context: Context) {
        registerMainAPI(Plusizle())
        registerExtractorAPI(HotStream())
    }
}
