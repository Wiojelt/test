version = 1

cloudstream {
    language = "tr"
    description = "TurkStream Studio test çıktısı"
    status = 3
    tvTypes = listOf("Movie", "TvSeries")
    iconUrl = "https://www.hdfilmizle.ink/wp-content/uploads/2023/04/hd-touch.webp"
}
