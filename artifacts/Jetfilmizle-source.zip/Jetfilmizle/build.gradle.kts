version = 4

cloudstream {
    language = "tr"
    description = "TurkStream test sağlayıcısı; katalog doğrulandı, oynatıcı akışı siteye göre beklemede olabilir."
    status = 3
    tvTypes = listOf("Movie", "TvSeries")
    iconUrl = "https://jetfilmizle.now/assets/img/logo.png"
}
