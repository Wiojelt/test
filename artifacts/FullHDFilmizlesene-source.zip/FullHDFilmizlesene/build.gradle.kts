version = 1

cloudstream {
    language = "tr"
    description = "TurkStream Studio test çıktısı"
    status = 3
    tvTypes = listOf("Movie", "TvSeries")
    iconUrl = "https://www.fullhdfilmizlesene.now/favicon.ico"
}
