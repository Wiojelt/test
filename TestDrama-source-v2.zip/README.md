# TestDrama v2

CloudStream kaynak kodu. Android SDK konumunu local.properties dosyasına ekleyin.

Build: `gradlew :TestDrama:make`

DramaFlix hesap girişi eklenti ayarlarında yapılır. Oturum yalnızca cihazda saklanır.
Gerçek CloudStream oynatımı ve ücretli hesap oturumu cihazda doğrulanmamıştır.
