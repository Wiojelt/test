# DiziKorea v16 source

Source adapted from Emre-Kahveci/CloudStreamHub DiziKorea module (upstream v15).
Build: ./gradlew :DiziKorea:make (Android SDK required).
Target test repository: https://github.com/Wiojelt/test
Film and series catalogs are included. Episode descriptions reflect the preparation message on the actual episode page. Vidmoly emits one HLS master source.
