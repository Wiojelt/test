version = 16

cloudstream {
    setRepo("Wiojelt/test")
    authors     = listOf("Wiojelt", "CloudStreamTR", "kraptor")
    language    = "tr"
    description = "Asya dizileri ve filmleri. Yayınlanmamış bölümlerde 'Bu bölümü sizler için hazırlıyoruz' bilgisi bölüm açıklamasında gösterilir."
    status      = 1
    tvTypes     = listOf("AsianDrama", "Movie")
    iconUrl     = "https://raw.githubusercontent.com/Wiojelt/test/main/assets/providers/DiziKorea.png"
}
