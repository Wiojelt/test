package com.cloudstream.tr.dizikorea

import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLEncoder
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.CancellationException

class DiziKorea : MainAPI() {
    override var mainUrl = "https://dizikorea3.com"
    override var name = "DiziKorea"
    override val hasMainPage = true
    override var lang = "tr"
    override val hasQuickSearch = true
    override val supportedTypes = setOf(TvType.AsianDrama, TvType.Movie)

    private val userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

    override val mainPage = mainPageOf(
        "${mainUrl}/" to "Son Eklenenler",
        "${mainUrl}/kore-dizileri-izle-dq1" to "Kore Dizileri",
        "${mainUrl}/cin-dizileri" to "Çin Dizileri",
        "${mainUrl}/japon-dizileri" to "Japon Dizileri",
        "${mainUrl}/tayland-dizileri" to "Tayland Dizileri",
        "${mainUrl}/tayvan-dizileri" to "Tayvan Dizileri",
        "${mainUrl}/filipin-dizileri" to "Filipin Dizileri",
        "${mainUrl}/filmler" to "Asya Filmleri"
    )

    override suspend fun getMainPage(page: Int, request: MainPageRequest): HomePageResponse {
        val targetUrl = if (page <= 1) {
            request.data
        } else {
            val base = request.data.removeSuffix("/")
            if (base.contains("?")) "${base}&page=${page}" else "${base}?page=${page}"
        }

        val document = app.get(targetUrl, headers = mapOf("User-Agent" to userAgent)).document
        val items = document.select("a.poster-card, div.content-grid a[href*='/dizi/'], div.grid a[href*='/dizi/'], div.grid a[href*='/film/']").mapNotNull { toSearchResult(it) }
        val deduped = items.distinctBy { it.url }

        return newHomePageResponse(request.name, deduped, hasNext = false)
    }

    fun toSearchResult(element: Element): SearchResponse? {
        val link = if (element.tagName() == "a") element else element.selectFirst("a[href*='/dizi/'], a[href*='/film/']") ?: return null
        var href = fixUrlNull(link.attr("href")) ?: return null
        
        if (href.contains("/sezon-")) {
            href = href.substringBefore("/sezon-")
        }

        val img = element.selectFirst("img")
        val title = img?.attr("alt")?.trim()
            ?.ifBlank { null }
            ?: element.selectFirst(".poster-card-title, h3, h2, .title")?.text()?.trim()
            ?: link.text().trim().takeIf { it.isNotBlank() }
            ?: return null

        val posterUrl = fixUrlNull(
            img?.attr("data-src")?.ifBlank { null }
                ?: img?.attr("src")?.ifBlank { null }
        )

        return if (href.contains("/film/")) {
            newMovieSearchResponse(title, href, TvType.Movie) { this.posterUrl = posterUrl }
        } else {
            newTvSeriesSearchResponse(title, href, TvType.AsianDrama) { this.posterUrl = posterUrl }
        }
    }

    override suspend fun search(query: String, page: Int): SearchResponseList {
        val encodedQuery = URLEncoder.encode(query, "UTF-8")
        val targetUrl = if (page <= 1) {
            "${mainUrl}/arama?q=${encodedQuery}"
        } else {
            "${mainUrl}/arama?q=${encodedQuery}&page=${page}"
        }

        val document = app.get(targetUrl, headers = mapOf("User-Agent" to userAgent)).document
        val items = parseSearchResults(document)
        return newSearchResponseList(items, hasNext = false)
    }

    fun parseSearchResults(document: Document): List<SearchResponse> {
        val elements = document.select("a.poster-card, div.content-grid a[href*='/dizi/'], div.grid a[href*='/dizi/'], div.grid a[href*='/film/']")
        val results = elements.mapNotNull { toSearchResult(it) }
        return results.distinctBy { it.url }
    }

    override suspend fun quickSearch(query: String): List<SearchResponse> = search(query, 1).items

    override suspend fun load(url: String): LoadResponse? {
        val document = app.get(url, headers = mapOf("User-Agent" to userAgent)).document
        return parseLoadMetadata(document, url)
    }

    suspend fun parseLoadMetadata(document: Document, url: String): LoadResponse? {
        val title = document.selectFirst("h1")?.text()?.trim() ?: return null
        val poster = fixUrlNull(
            document.selectFirst(".series-hero-panel-bg img, div.series-profile-poster img, div.series-header img, img[src*='series/']")?.let {
                it.attr("data-src").ifBlank { null } ?: it.attr("src").ifBlank { null }
            } ?: document.selectFirst("meta[property='og:image']")?.attr("content")
        )
        val description = document.selectFirst(".series-about-preview, .series-about-p1, div.series-about-body p, div.description")?.text()?.trim()

        if (url.contains("/film/")) {
            return newMovieLoadResponse(title, url, TvType.Movie, url) {
                this.posterUrl = poster
                this.plot = description
            }
        }

        val episodeElements = document.select("a[href*='/sezon-']")
        val episodes = mutableListOf<Episode>()

        val epRegex = Regex("""/sezon-(\d+)/bolum-(\d+)""")
        val seenUrls = mutableSetOf<String>()
        val episodeUrls = episodeElements.mapNotNull { element ->
            fixUrlNull(element.attr("href"))?.takeIf { epRegex.containsMatchIn(it) }
        }.distinct()
        val preparingUrls = coroutineScope {
            episodeUrls.chunked(8).flatMap { batch ->
                batch.map { episodeUrl ->
                    async {
                        val preparing = try {
                            app.get(episodeUrl, headers = mapOf("User-Agent" to userAgent)).text
                                .contains("Bu bölümü sizler için hazırlıyoruz", ignoreCase = true)
                        } catch (cancelled: CancellationException) {
                            throw cancelled
                        } catch (_: Exception) {
                            false
                        }
                        episodeUrl to preparing
                    }
                }.awaitAll()
            }
        }.filter { it.second }.map { it.first }.toSet()

        for (el in episodeElements) {
            val href = fixUrlNull(el.attr("href")) ?: continue
            if (!seenUrls.add(href)) continue

            val match = epRegex.find(href)
            val seasonNum = match?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 1
            val epNum = match?.groupValues?.getOrNull(2)?.toIntOrNull() ?: 1

            val epName = el.selectFirst(".ep-title")?.text()?.trim()?.takeIf { it.isNotBlank() }
                ?: "$seasonNum. Sezon $epNum. Bölüm"
            val releaseText = el.selectFirst(".ep-date")?.text()?.trim().orEmpty()
            val preparing = href in preparingUrls

            episodes.add(
                newEpisode(href) {
                    this.name = epName
                    this.season = seasonNum
                    this.episode = epNum
                    if (preparing) this.description = "Bu bölümü sizler için hazırlıyoruz. Yayın tarihi: $releaseText"
                }
            )
        }

        return newTvSeriesLoadResponse(title, url, TvType.AsianDrama, episodes) {
            this.posterUrl = poster
            this.plot = description
        }
    }

    private suspend fun resolveVidmoly(
        iframeUrl: String,
        episodeUrl: String,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val html = app.get(
            iframeUrl,
            headers = mapOf("Referer" to episodeUrl, "User-Agent" to userAgent)
        ).text
        val source = Regex("""sources\s*:\s*\[\s*\{\s*file\s*:\s*['\"](https?[^'\"]+)['\"]""")
            .find(html)?.groupValues?.getOrNull(1)
            ?.replace("\\/", "/")?.replace("&amp;", "&") ?: return false
        if (!source.startsWith("https://") || !source.contains(".m3u8")) return false
        val referer = Regex("""https?://[^/]+/""").find(iframeUrl)?.value ?: return false
        val headers = mapOf("Referer" to referer, "User-Agent" to userAgent)
        val manifest = app.get(source, headers = headers).text
        if (!manifest.trimStart().startsWith("#EXTM3U")) return false
        callback(newExtractorLink(
            source = name,
            name = "Vidmoly",
            url = source,
            type = ExtractorLinkType.M3U8
        ) {
            this.referer = referer
            this.headers = headers
        })
        return true
    }

    private suspend fun resolvePlayerDkorea(
        playerUrl: String,
        pageUrl: String,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        return try {
            val videoId = Regex("""/video/([a-zA-Z0-9_-]+)""").find(playerUrl)?.groupValues?.get(1) ?: return false
            val host = Regex("""https?://[^/]+""").find(playerUrl)?.value ?: "https://playerdkorea.xyz"
            val apiUrl = "${host}/player/index.php?data=${videoId}&do=getVideo"

            val apiResp = app.post(
                apiUrl,
                data = mapOf(
                    "hash" to videoId,
                    "r" to pageUrl,
                    "s" to ""
                ),
                headers = mapOf(
                    "X-Requested-With" to "XMLHttpRequest",
                    "Referer" to playerUrl,
                    "User-Agent" to userAgent
                )
            ).text

            val streamMatch = Regex(""""securedLink"\s*:\s*"([^"]+)"""").find(apiResp)
                ?: Regex(""""videoSource"\s*:\s*"([^"]+)"""").find(apiResp)
                ?: Regex("""https?://[^"'\s<>]+\.m3u8[^"'\s<>]*""").find(apiResp)

            val streamUrl = streamMatch?.groupValues?.getOrNull(1)?.replace("\\/", "/")
                ?: streamMatch?.value?.replace("\\/", "/")

            if (!streamUrl.isNullOrBlank() && streamUrl.startsWith("https://") && streamUrl.contains(".m3u8") &&
                app.get(streamUrl, headers = mapOf("Referer" to "${host}/", "User-Agent" to userAgent))
                    .text.trimStart().startsWith("#EXTM3U")) {
                callback(
                    newExtractorLink(
                        source = name,
                        name = "VIP",
                        url = streamUrl,
                        type = ExtractorLinkType.M3U8
                    ) {
                        this.referer = "${host}/"
                        this.headers = mapOf(
                            "Referer" to "${host}/",
                            "User-Agent" to userAgent
                        )
                    }
                )
                true
            } else {
                false
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            false
        }
    }

    override suspend fun loadLinks(
        data: String,
        isCasting: Boolean,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val document = app.get(data, headers = mapOf("User-Agent" to userAgent)).document
        var found = false
        val candidates = document.select("iframe[data-src], iframe[src]")
            .mapNotNull { fixUrlNull(it.attr("data-src").ifBlank { it.attr("src") }) }
            .filter { it.startsWith("https://") }
            .distinct()
            .sortedBy { when {
                it.contains("vidmoly", ignoreCase = true) -> 0
                it.contains("playerdkorea", ignoreCase = true) -> 1
                else -> 2
            } }
        for (iframeUrl in candidates) {
            try {
                when {
                    iframeUrl.contains("vidmoly", ignoreCase = true) -> {
                        if (resolveVidmoly(iframeUrl, data, callback)) found = true
                    }
                    iframeUrl.contains("playerdkorea", ignoreCase = true) -> {
                        if (resolvePlayerDkorea(iframeUrl, data) { link ->
                                callback(link)
                                found = true
                            }) found = true
                    }
                    iframeUrl.contains("bysedikamoum", ignoreCase = true) || iframeUrl.contains("filemoon", ignoreCase = true) -> {
                        // New Filemoon/Byse embeds require player verification; emit only real media.
                        loadExtractor(iframeUrl, data, subtitleCallback) { link ->
                            callback(link)
                            found = true
                        }
                    }
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                // A failed mirror must not hide a working one.
            }
        }
        return found
    }
}
