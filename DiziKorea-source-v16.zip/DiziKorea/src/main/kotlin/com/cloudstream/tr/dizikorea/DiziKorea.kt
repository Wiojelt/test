package com.cloudstream.tr.dizikorea

import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import com.fasterxml.jackson.annotation.JsonProperty
import com.lagradost.cloudstream3.utils.AppUtils.tryParseJson
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import java.nio.charset.StandardCharsets
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import java.net.URLEncoder
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.CancellationException

class DiziKorea : MainAPI() {
    override var mainUrl = "https://dizikorea3.com"
    override var name = "DiziKorea"
    override val hasMainPage = true
    override var lang = "tr"
    override val hasQuickSearch = true
    override val supportedTypes = setOf(TvType.AsianDrama, TvType.Movie)

    private val userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

    private data class BysePlaybackEnvelope(@JsonProperty("playback") val playback: BysePlayback? = null)
    private data class BysePlayback(
        val iv: String = "",
        val payload: String = "",
        @JsonProperty("key_parts") val keyParts: List<String> = emptyList(),
        val version: String = ""
    )
    private data class BysePayload(
        val sources: List<ByseSource> = emptyList(),
        val tracks: List<ByseTrack> = emptyList()
    )
    private data class ByseSource(
        val url: String? = null,
        val label: String? = null,
        val height: Int? = null
    )
    private data class ByseTrack(
        val url: String? = null,
        val language: String? = null,
        val title: String? = null
    )
    private data class ByseChallenge(
        @JsonProperty("pow_nonce") val nonce: String = "",
        @JsonProperty("pow_difficulty") val difficulty: Int = 0,
        @JsonProperty("pow_token") val token: String = ""
    )
    private data class ByseCaptchaVerification(
        val status: String = "",
        val token: String? = null
    )

    private fun decodeBase64Url(value: String): ByteArray {
        val normalized = value.replace('-', '+').replace('_', '/')
            .padEnd((value.length + 3) / 4 * 4, '=')
        return Base64.getDecoder().decode(normalized)
    }

    private fun rotate(value: Int, bits: Int): Int = Integer.rotateLeft(value, bits)

    private fun mix(state: IntArray) {
        state[0] += state[1]
        state[3] = rotate(state[3] xor state[0], 16)
        state[2] += state[3]
        state[1] = rotate(state[1] xor state[2], 12)
        state[0] += state[1]
        state[3] = rotate(state[3] xor state[0], 8)
        state[2] += state[3]
        state[1] = rotate(state[1] xor state[2], 7)
    }

    private fun byseHash(value: String): IntArray {
        val state = intArrayOf(1779033703, 3144134277.toInt(), 1013904242, 2773480762.toInt())
        value.forEach { ch ->
            state[0] += ch.code and 255
            state[0] = rotate(state[0], 7)
            mix(state)
        }
        repeat(8) { mix(state) }
        val memory = IntArray(512)
        repeat(512) { index ->
            mix(state)
            memory[index] = state[0] xor state[2]
        }
        repeat(2) {
            repeat(512) { index ->
                val at = memory[index] and 511
                var current = memory[index] + memory[at]
                current = rotate(current, 13)
                current = current xor (memory[(index + 1) and 511] * 2654435761.toInt())
                memory[index] = current
                state[0] = state[0] xor current
                mix(state)
            }
        }
        val output = IntArray(8)
        repeat(8) { index ->
            mix(state)
            var current = state[0]
            repeat(64) { offset ->
                val item = memory[index * 64 + offset]
                current = rotate(current + item, 5)
                current = current xor (item * 2246822519.toInt())
            }
            output[index] = current xor state[2]
        }
        return output
    }

    private fun leadingZeroBits(values: IntArray): Int {
        var count = 0
        for (value in values) {
            if (value == 0) {
                count += 32
            } else {
                return count + Integer.numberOfLeadingZeros(value)
            }
        }
        return count
    }

    private fun solveBysePow(nonce: String, difficulty: Int): String? {
        if (difficulty <= 0) return "0"
        for (solution in 0 until 2_000_000) {
            if (leadingZeroBits(byseHash("$nonce:$solution")) >= difficulty) return solution.toString()
        }
        return null
    }

    private fun decryptByse(playback: BysePlayback): BysePayload? {
        val version = playback.version.filter { it.isDigit() }.toIntOrNull() ?: return null
        if (playback.keyParts.isEmpty() || version !in 1..playback.keyParts.size) return null
        val order = listOf(playback.keyParts[version - 1], playback.keyParts[playback.keyParts.size - version])
        val key = order.flatMap { decodeBase64Url(it).asList() }.toByteArray()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, decodeBase64Url(playback.iv)))
        val clear = cipher.doFinal(decodeBase64Url(playback.payload))
        return tryParseJson(String(clear, StandardCharsets.UTF_8))
    }

    override val mainPage = mainPageOf(
        "${mainUrl}/" to "Son Eklenenler",
        "${mainUrl}/kore-dizileri-izle-dq1" to "Kore Dizileri",
        "${mainUrl}/cin-dizileri" to "Çin Dizileri",
        "${mainUrl}/japon-dizileri" to "Japon Dizileri",
        "${mainUrl}/tayland-dizileri" to "Tayland Dizileri",
        "${mainUrl}/tayvan-dizileri" to "Tayvan Dizileri",
        "${mainUrl}/filipin-dizileri" to "Filipin Dizileri",
        "${mainUrl}/filmler" to "Asya Filmleri"
    )

    override suspend fun getMainPage(page: Int, request: MainPageRequest): HomePageResponse {
        val targetUrl = if (page <= 1) {
            request.data
        } else {
            val base = request.data.removeSuffix("/")
            if (base.contains("?")) "${base}&page=${page}" else "${base}?page=${page}"
        }

        val document = app.get(targetUrl, headers = mapOf("User-Agent" to userAgent)).document
        val items = document.select("a.poster-card, div.content-grid a[href*='/dizi/'], div.grid a[href*='/dizi/'], div.grid a[href*='/film/']").mapNotNull { toSearchResult(it) }
        val deduped = items.distinctBy { it.url }

        return newHomePageResponse(request.name, deduped, hasNext = false)
    }

    fun toSearchResult(element: Element): SearchResponse? {
        val link = if (element.tagName() == "a") element else element.selectFirst("a[href*='/dizi/'], a[href*='/film/']") ?: return null
        var href = fixUrlNull(link.attr("href")) ?: return null
        
        if (href.contains("/sezon-")) {
            href = href.substringBefore("/sezon-")
        }

        val img = element.selectFirst("img")
        val title = img?.attr("alt")?.trim()
            ?.ifBlank { null }
            ?: element.selectFirst(".poster-card-title, h3, h2, .title")?.text()?.trim()
            ?: link.text().trim().takeIf { it.isNotBlank() }
            ?: return null

        val posterUrl = fixUrlNull(
            img?.attr("data-src")?.ifBlank { null }
                ?: img?.attr("src")?.ifBlank { null }
        )

        return if (href.contains("/film/")) {
            newMovieSearchResponse(title, href, TvType.Movie) { this.posterUrl = posterUrl }
        } else {
            newTvSeriesSearchResponse(title, href, TvType.AsianDrama) { this.posterUrl = posterUrl }
        }
    }

    override suspend fun search(query: String, page: Int): SearchResponseList {
        val encodedQuery = URLEncoder.encode(query, "UTF-8")
        val targetUrl = if (page <= 1) {
            "${mainUrl}/arama?q=${encodedQuery}"
        } else {
            "${mainUrl}/arama?q=${encodedQuery}&page=${page}"
        }

        val document = app.get(targetUrl, headers = mapOf("User-Agent" to userAgent)).document
        val items = parseSearchResults(document)
        return newSearchResponseList(items, hasNext = false)
    }

    fun parseSearchResults(document: Document): List<SearchResponse> {
        val elements = document.select("a.poster-card, div.content-grid a[href*='/dizi/'], div.grid a[href*='/dizi/'], div.grid a[href*='/film/']")
        val results = elements.mapNotNull { toSearchResult(it) }
        return results.distinctBy { it.url }
    }

    override suspend fun quickSearch(query: String): List<SearchResponse> = search(query, 1).items

    override suspend fun load(url: String): LoadResponse? {
        val document = app.get(url, headers = mapOf("User-Agent" to userAgent)).document
        return parseLoadMetadata(document, url)
    }

    suspend fun parseLoadMetadata(document: Document, url: String): LoadResponse? {
        val title = document.selectFirst("h1")?.text()?.trim() ?: return null
        val poster = fixUrlNull(
            document.selectFirst(".series-hero-panel-bg img, div.series-profile-poster img, div.series-header img, img[src*='series/']")?.let {
                it.attr("data-src").ifBlank { null } ?: it.attr("src").ifBlank { null }
            } ?: document.selectFirst("meta[property='og:image']")?.attr("content")
        )
        val description = document.selectFirst(".series-about-preview, .series-about-p1, div.series-about-body p, div.description")?.text()?.trim()

        if (url.contains("/film/")) {
            return newMovieLoadResponse(title, url, TvType.Movie, url) {
                this.posterUrl = poster
                this.plot = description
            }
        }

        val episodeElements = document.select("a[href*='/sezon-']")
        val episodes = mutableListOf<Episode>()

        val epRegex = Regex("""/sezon-(\d+)/bolum-(\d+)""")
        val seenUrls = mutableSetOf<String>()
        val episodeUrls = episodeElements.mapNotNull { element ->
            fixUrlNull(element.attr("href"))?.takeIf { epRegex.containsMatchIn(it) }
        }.distinct()
        val preparingUrls = coroutineScope {
            episodeUrls.chunked(8).flatMap { batch ->
                batch.map { episodeUrl ->
                    async {
                        val preparing = try {
                            app.get(episodeUrl, headers = mapOf("User-Agent" to userAgent)).text
                                .contains("Bu bölümü sizler için hazırlıyoruz", ignoreCase = true)
                        } catch (cancelled: CancellationException) {
                            throw cancelled
                        } catch (_: Exception) {
                            false
                        }
                        episodeUrl to preparing
                    }
                }.awaitAll()
            }
        }.filter { it.second }.map { it.first }.toSet()

        for (el in episodeElements) {
            val href = fixUrlNull(el.attr("href")) ?: continue
            if (!seenUrls.add(href)) continue

            val match = epRegex.find(href)
            val seasonNum = match?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 1
            val epNum = match?.groupValues?.getOrNull(2)?.toIntOrNull() ?: 1

            val epName = el.selectFirst(".ep-title")?.text()?.trim()?.takeIf { it.isNotBlank() }
                ?: "$seasonNum. Sezon $epNum. Bölüm"
            val releaseText = el.selectFirst(".ep-date")?.text()?.trim().orEmpty()
            val preparing = href in preparingUrls

            episodes.add(
                newEpisode(href) {
                    this.name = epName
                    this.season = seasonNum
                    this.episode = epNum
                    if (preparing) this.description = "Bu bölümü sizler için hazırlıyoruz. Yayın tarihi: $releaseText"
                }
            )
        }

        return newTvSeriesLoadResponse(title, url, TvType.AsianDrama, episodes) {
            this.posterUrl = poster
            this.plot = description
        }
    }

    private suspend fun resolveVidmoly(
        iframeUrl: String,
        episodeUrl: String,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val html = app.get(
            iframeUrl,
            headers = mapOf("Referer" to episodeUrl, "User-Agent" to userAgent)
        ).text
        val source = Regex("""sources\s*:\s*\[\s*\{\s*file\s*:\s*['\"](https?[^'\"]+)['\"]""")
            .find(html)?.groupValues?.getOrNull(1)
            ?.replace("\\/", "/")?.replace("&amp;", "&") ?: return false
        if (!source.startsWith("https://") || !source.contains(".m3u8")) return false
        val referer = Regex("""https?://[^/]+/""").find(iframeUrl)?.value ?: return false
        val headers = mapOf("Referer" to referer, "User-Agent" to userAgent)
        val manifest = app.get(source, headers = headers).text
        if (!manifest.trimStart().startsWith("#EXTM3U")) return false
        callback(newExtractorLink(
            source = name,
            name = "Vidmoly",
            url = source,
            type = ExtractorLinkType.M3U8
        ) {
            this.referer = referer
            this.headers = headers
        })
        return true
    }

    private suspend fun resolveByse(
        iframeUrl: String,
        episodeUrl: String,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val code = iframeUrl.substringBefore('?').trimEnd('/').substringAfterLast('/').takeIf { it.isNotBlank() }
            ?: return false
        val base = Regex("""https?://[^/]+""").find(iframeUrl)?.value ?: return false
        val commonHeaders = mapOf(
            "Referer" to episodeUrl,
            "Origin" to base,
            "User-Agent" to userAgent,
            "X-Embed-Origin" to "https://dizikorea3.com",
            "X-Embed-Referer" to episodeUrl,
            "X-Embed-Parent" to iframeUrl
        )
        val details = app.get("$base/api/videos/$code/embed/details", headers = commonHeaders).text
        val frameUrl = Regex("""\"embed_frame_url\"\s*:\s*\"([^\"]+)\"""")
            .find(details)?.groupValues?.getOrNull(1)?.replace("\\/", "/") ?: return false
        val frameBase = Regex("""https?://[^/]+""").find(frameUrl)?.value ?: return false
        val frameCode = frameUrl.trimEnd('/').substringAfterLast('/').takeIf { it.isNotBlank() } ?: return false
        val apiBase = "$frameBase/api/videos/$frameCode/embed"
        val jsonHeaders = commonHeaders + ("Content-Type" to "application/json") + ("Referer" to frameUrl)
        val emptyJson = "{}".toRequestBody("application/json; charset=utf-8".toMediaTypeOrNull())
        val challenge = app.post("$apiBase/captcha", headers = jsonHeaders, requestBody = emptyJson).parsedSafe<ByseChallenge>()
            ?: return false
        val solution = solveBysePow(challenge.nonce, challenge.difficulty) ?: return false
        val verifyBody = "{\"pow_token\":\"${challenge.token}\",\"solution\":\"$solution\"}"
            .toRequestBody("application/json; charset=utf-8".toMediaTypeOrNull())
        val verified = app.post("$apiBase/captcha/verify", headers = jsonHeaders, requestBody = verifyBody)
            .parsedSafe<ByseCaptchaVerification>() ?: return false
        val captchaToken = verified.token?.takeIf { verified.status == "ok" } ?: return false
        val playback = app.post(
            "$apiBase/playback",
            headers = jsonHeaders + ("X-Captcha-Token" to captchaToken),
            requestBody = emptyJson
        ).parsedSafe<BysePlaybackEnvelope>()?.playback ?: return false
        val payload = decryptByse(playback) ?: return false
        var found = false
        payload.tracks.forEach { track ->
            val url = track.url?.takeIf { it.startsWith("https://") } ?: return@forEach
            subtitleCallback(SubtitleFile(lang = track.title ?: track.language ?: "Altyazı", url = url))
        }
        payload.sources.forEach { source ->
            val url = source.url?.takeIf { it.startsWith("https://") } ?: return@forEach
            val headers = mapOf("Referer" to frameUrl, "User-Agent" to userAgent)
            if (url.contains(".m3u8", ignoreCase = true)) {
                val manifest = app.get(url, headers = headers).text
                if (!manifest.trimStart().startsWith("#EXTM3U")) return@forEach
                callback(newExtractorLink(source = name, name = "Filemoon", url = url, type = ExtractorLinkType.M3U8) {
                    this.referer = frameUrl
                    this.headers = headers
                })
                found = true
            } else {
                callback(newExtractorLink(source = name, name = "Filemoon", url = url, type = ExtractorLinkType.VIDEO) {
                    this.referer = frameUrl
                    this.headers = headers
                    this.quality = source.height ?: Qualities.Unknown.value
                })
                found = true
            }
        }
        return found
    }

    private suspend fun resolvePlayerDkorea(
        playerUrl: String,
        pageUrl: String,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        return try {
            val videoId = Regex("""/video/([a-zA-Z0-9_-]+)""").find(playerUrl)?.groupValues?.get(1) ?: return false
            val host = Regex("""https?://[^/]+""").find(playerUrl)?.value ?: "https://playerdkorea.xyz"
            val apiUrl = "${host}/player/index.php?data=${videoId}&do=getVideo"

            val apiResp = app.post(
                apiUrl,
                data = mapOf(
                    "hash" to videoId,
                    "r" to pageUrl,
                    "s" to ""
                ),
                headers = mapOf(
                    "X-Requested-With" to "XMLHttpRequest",
                    "Referer" to playerUrl,
                    "User-Agent" to userAgent
                )
            ).text

            val streamMatch = Regex(""""securedLink"\s*:\s*"([^"]+)"""").find(apiResp)
                ?: Regex(""""videoSource"\s*:\s*"([^"]+)"""").find(apiResp)
                ?: Regex("""https?://[^"'\s<>]+\.m3u8[^"'\s<>]*""").find(apiResp)

            val streamUrl = streamMatch?.groupValues?.getOrNull(1)?.replace("\\/", "/")
                ?: streamMatch?.value?.replace("\\/", "/")

            if (!streamUrl.isNullOrBlank() && streamUrl.startsWith("https://") && streamUrl.contains(".m3u8") &&
                app.get(streamUrl, headers = mapOf("Referer" to "${host}/", "User-Agent" to userAgent))
                    .text.trimStart().startsWith("#EXTM3U")) {
                callback(
                    newExtractorLink(
                        source = name,
                        name = "VIP",
                        url = streamUrl,
                        type = ExtractorLinkType.M3U8
                    ) {
                        this.referer = "${host}/"
                        this.headers = mapOf(
                            "Referer" to "${host}/",
                            "User-Agent" to userAgent
                        )
                    }
                )
                true
            } else {
                false
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            false
        }
    }

    override suspend fun loadLinks(
        data: String,
        isCasting: Boolean,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val document = app.get(data, headers = mapOf("User-Agent" to userAgent)).document
        var found = false
        val candidates = document.select("iframe[data-src], iframe[src]")
            .mapNotNull { fixUrlNull(it.attr("data-src").ifBlank { it.attr("src") }) }
            .filter { it.startsWith("https://") }
            .distinct()
            .sortedBy { when {
                it.contains("vidmoly", ignoreCase = true) -> 0
                it.contains("playerdkorea", ignoreCase = true) -> 1
                else -> 2
            } }
        for (iframeUrl in candidates) {
            try {
                when {
                    iframeUrl.contains("vidmoly", ignoreCase = true) -> {
                        if (resolveVidmoly(iframeUrl, data, callback)) found = true
                    }
                    iframeUrl.contains("playerdkorea", ignoreCase = true) -> {
                        if (resolvePlayerDkorea(iframeUrl, data) { link ->
                                callback(link)
                                found = true
                            }) found = true
                    }
                    iframeUrl.contains("bysedikamoum", ignoreCase = true) || iframeUrl.contains("filemoon", ignoreCase = true) -> {
                        if (resolveByse(iframeUrl, data, subtitleCallback, callback)) found = true
                    }
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                // A failed mirror must not hide a working one.
            }
        }
        return found
    }
}
