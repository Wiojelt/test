version = 11

cloudstream {
    setRepo("Wiojelt/test")
    description = "SeyirTURK · Yerli ve yabancı filmler, diziler ve canlı TV kanalları."
    authors = listOf("Wiojelt")
    language = "tr"
    status = 1
    tvTypes = listOf("Movie", "TvSeries", "Live")
    requiresResources = false
}
