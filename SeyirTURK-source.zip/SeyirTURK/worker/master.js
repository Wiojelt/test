// Build a short-lived HLS master for sites that expose only separate fixed HLS playlists.
// The worker never fetches or proxies media. It only returns the URLs supplied by the provider.
export default {
  async fetch(request) {
    const parsed = new URL(request.url);
    if (parsed.pathname !== "/master.m3u8") return new Response("Not found", { status: 404 });
    const q = parsed.searchParams.get("q") || "";
    if (q.length > 3500 || !/^[A-Za-z0-9_-]+$/.test(q)) {
      return new Response("Invalid playlist", { status: 400 });
    }
    try {
      const binary = atob(q.replace(/-/g, "+").replace(/_/g, "/"));
      const bytes = Uint8Array.from(binary, c => c.charCodeAt(0));
      const entries = JSON.parse(new TextDecoder().decode(bytes));
      if (!Array.isArray(entries) || entries.length < 2 || entries.length > 8) throw Error();
      const variants = entries.map(entry => {
        const height = Number(entry.height);
        const url = new URL(entry.url);
        if (!Number.isInteger(height) || height < 144 || height > 2160 ||
            url.protocol !== "https:" || !url.pathname.endsWith(".m3u8")) throw Error();
        const width = Math.round(height * 16 / 9 / 2) * 2;
        return { height, width, url: url.toString() };
      }).sort((a, b) => a.height - b.height);
      const lines = ["#EXTM3U", "#EXT-X-VERSION:3"];
      for (const item of variants) {
        lines.push(`#EXT-X-STREAM-INF:BANDWIDTH=${Math.round(item.height * item.height * 5)},RESOLUTION=${item.width}x${item.height}`);
        lines.push(item.url);
      }
      return new Response(lines.join("\n") + "\n", {
        headers: {
          "Content-Type": "application/vnd.apple.mpegurl; charset=utf-8",
          "Cache-Control": "no-store",
          "Access-Control-Allow-Origin": "*",
        },
      });
    } catch (_) {
      return new Response("Invalid playlist", { status: 400 });
    }
  },
};
