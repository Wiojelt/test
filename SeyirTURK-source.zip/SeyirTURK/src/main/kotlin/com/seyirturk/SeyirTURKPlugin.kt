package com.seyirturk

import android.content.Context
import com.lagradost.cloudstream3.plugins.CloudstreamPlugin
import com.lagradost.cloudstream3.plugins.Plugin

@CloudstreamPlugin
class SeyirTURKPlugin : Plugin() {
    override fun load(context: Context) {
        registerExtractorAPI(SeyirTURKVidmixi())
        registerExtractorAPI(CloseLoad())
        registerExtractorAPI(RapidFilmMakinesi())
        registerMainAPI(SeyirTURK())
    }
}
