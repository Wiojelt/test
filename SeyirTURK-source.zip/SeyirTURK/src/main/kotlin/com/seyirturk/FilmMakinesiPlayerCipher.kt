package com.seyirturk

import android.util.Base64

/** Resolves the stream variable used by the site's current Close and Rapid players. */
internal object FilmMakinesiPlayerCipher {
    fun resolve(html: String): String? = runCatching {
        val script = html + "\n" + unpackAll(html)
        val streamVariable = Regex("""sources\s*:\s*\[\s*\{\s*file\s*:\s*([A-Za-z]\w*)""")
            .findAll(script).lastOrNull()?.groupValues?.get(1) ?: return null
        val assignment = Regex(
            """var\s+${Regex.escape(streamVariable)}\s*=\s*(\w+)\(\s*"([^"]+)"\.split\("([^"]+)"\)\s*\)"""
        ).find(script) ?: return null
        val functionName = assignment.groupValues[1]
        val parts = assignment.groupValues[2].split(assignment.groupValues[3]).toMutableList()
        val definition = Regex(
            """(?:function\s+${Regex.escape(functionName)}\s*\(|var\s+${Regex.escape(functionName)}\s*=\s*function\s*\()"""
        ).findAll(script.substring(0, assignment.range.first)).lastOrNull() ?: return null
        val body = script.substring(definition.range.first, assignment.range.first)
        val media = if (body.contains("splice(")) decodeSpliced(parts) else decodeJoined(parts, body)
        media?.takeIf { it.startsWith("https://") || it.startsWith("http://") }
    }.getOrNull()

    private fun unpackAll(html: String): String {
        val packed = Regex(
            """\}\('((?:\\.|[^'])*)',\s*(\d+),\s*(\d+),\s*'((?:\\.|[^'])*)'\.split\('\|'\)""",
            RegexOption.DOT_MATCHES_ALL
        )
        return packed.findAll(html).joinToString("\n") { match ->
            val words = match.groupValues[4].split('|')
            var code = match.groupValues[1].replace("\\'", "'").replace("\\\\", "\\")
            for (index in words.indices.reversed()) {
                if (words[index].isNotEmpty()) {
                    code = code.replace(Regex("""\b${Regex.escape(base62(index))}\b""")) { words[index] }
                }
            }
            code
        }
    }

    private fun base62(number: Int): String {
        if (number == 0) return "0"
        val alphabet = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
        var remaining = number
        val result = StringBuilder()
        while (remaining > 0) {
            result.append(alphabet[remaining % 62])
            remaining /= 62
        }
        return result.reverse().toString()
    }

    private fun decodeJoined(parts: List<String>, body: String): String? {
        val key = Regex("""var\s+\w+\s*=\s*"([A-Za-z0-9]{15,35})"""")
            .find(body)?.groupValues?.get(1) ?: return null
        val operations = Regex("""var\s+\w+\s*=\s*"([A-Za-z]{2,8})"""")
            .find(body)?.groupValues?.get(1) ?: return null
        var q = 0
        var p = 0
        key.forEachIndexed { index, character ->
            q = (q * 31 + character.code) % 251
            p = (p xor (character.code + index)) and 255
        }
        var value = parts.joinToString("")
        for (operation in operations.reversed()) {
            value = when (operation) {
                'b' -> decodeBase64(value) ?: return null
                'v' -> value.reversed()
                else -> rotateLetters(value, (26 - ((operation.code - 64) % 26)) % 26)
            }
        }
        return unscramble(value, (q * 256 + p) % 65521 + 1, 75, 74, 65537,
            (q + p) % 256, q % 13 + 3, false)
    }

    private fun decodeSpliced(parts: MutableList<String>): String? {
        val length = parts.size - 2
        val operations = parts.removeAt(8 + length % 5)
        val key = parts.removeAt(length % 7)
        var q = 0
        var p = 0
        key.forEachIndexed { index, character ->
            q = (q * 37 + character.code) % 241
            p = (p + ((character.code shl 1) xor index)) and 255
        }
        var value = parts.joinToString("")
        for (operation in operations.reversed()) {
            value = when (operation) {
                '7' -> decodeBase64(value) ?: return null
                '3' -> value.reversed()
                else -> rotateLetters(value, (26 - ((operation.code - 96) % 26)) % 26)
            }
        }
        return unscramble(value, (p * 251 + q) % 65519 + 1, 97, 41, 65519,
            (q * 3 + p) % 256, p % 11 + 5, true)
    }

    private fun decodeBase64(value: String): String? = runCatching {
        String(Base64.decode(value, Base64.DEFAULT), Charsets.ISO_8859_1)
    }.getOrNull()

    private fun rotateLetters(value: String, offset: Int): String = buildString(value.length) {
        for (character in value) {
            val base = when (character) {
                in 'A'..'Z' -> 65
                in 'a'..'z' -> 97
                else -> null
            }
            append(if (base == null) character else ((character.code - base + offset) % 26 + base).toChar())
        }
    }

    private fun unscramble(
        input: String, initialSeed: Int, multiplier: Int, addend: Int, modulus: Int,
        initialCounter: Int, step: Int, multipliedCounter: Boolean
    ): String {
        var seed = initialSeed
        val indexes = IntArray(input.length)
        for (index in input.length - 1 downTo 1) {
            seed = (seed * multiplier + addend) % modulus
            indexes[index] = seed % (index + 1)
        }
        val characters = input.toCharArray()
        for (index in 1 until characters.size) {
            val swap = indexes[index]
            val previous = characters[index]
            characters[index] = characters[swap]
            characters[swap] = previous
        }
        var counter = initialCounter
        return buildString(characters.size) {
            for (character in characters) {
                counter = if (multipliedCounter) (counter * 5 + step) % 256 else (counter + step) % 256
                append((character.code xor counter).toChar())
                counter = (counter + character.code) % 256
            }
        }.trim()
    }
}

