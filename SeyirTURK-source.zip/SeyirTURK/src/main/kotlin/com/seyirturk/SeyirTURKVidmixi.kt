package com.seyirturk

import com.lagradost.cloudstream3.SubtitleFile
import com.lagradost.cloudstream3.app
import com.lagradost.cloudstream3.extractors.helper.AesHelper
import com.lagradost.cloudstream3.utils.ExtractorApi
import com.lagradost.cloudstream3.utils.ExtractorLink
import com.lagradost.cloudstream3.utils.ExtractorLinkType
import com.lagradost.cloudstream3.utils.M3u8Helper
import com.lagradost.cloudstream3.utils.newExtractorLink
import org.json.JSONObject

/** Vidmixi's current bePlayer payload is AES encrypted; the page URL is not a media URL. */
class SeyirTURKVidmixi : ExtractorApi() {
    override val name = "Vidmixi"
    override val mainUrl = "https://vidmixi.com"
    override val requiresReferer = true

    override suspend fun getUrl(
        url: String,
        referer: String?,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ) {
        val html = app.get(url, referer = referer ?: "https://fullhdfilmizle.now/").text
        val encrypted = Regex("""bePlayer\('([^']+)',\s*'(\{[^}]+})'\)""")
            .find(html)?.groupValues ?: return
        val decrypted = AesHelper.cryptoAESHandler(encrypted[2], encrypted[1].toByteArray(), false)
            ?.replace("\\/", "/") ?: return
        val payload = runCatching { JSONObject(decrypted) }.getOrNull() ?: return
        val media = payload.optString("video_location")
        if (!media.startsWith("http")) return
        val streamHeaders = mapOf("Referer" to url)
        val variants = runCatching {
            M3u8Helper.generateM3u8(name, media, url, headers = streamHeaders)
        }.getOrDefault(emptyList())
        val qualityLinks = selectQualityVariants(variants)
        if (qualityLinks.isNotEmpty()) qualityLinks.forEach(callback)
        else callback(newExtractorLink(name, name, media, ExtractorLinkType.M3U8) {
            this.referer = url
            headers = streamHeaders
        })
        val tracks = payload.optJSONArray("strSubtitles")
        if (tracks != null) for (index in 0 until tracks.length()) {
            val track = tracks.optJSONObject(index) ?: continue
            val path = track.optString("file")
            if (path.isBlank()) continue
            val absolute = runCatching { java.net.URI(url).resolve(path).toString() }.getOrNull() ?: continue
            subtitleCallback(SubtitleFile(track.optString("label").ifBlank { "Altyazı" }, absolute))
        }
    }
}
