package com.seyirturk

import com.lagradost.cloudstream3.utils.ExtractorLink
import com.lagradost.cloudstream3.utils.Qualities

/** M3u8Helper may include the master playlist beside its actual resolutions. */
internal fun selectQualityVariants(links: List<ExtractorLink>): List<ExtractorLink> {
    val playable = links.filter { it.url.startsWith("http") }
    val explicit = playable.filter { it.quality != Qualities.Unknown.value }
    val selected = if (explicit.isNotEmpty()) explicit else playable.take(1)
    return selected.distinctBy { it.url to it.quality }
}
