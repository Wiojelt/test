package com.seyirturk

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class MovieItem(
    @JsonProperty("ID") val id: String? = null,
    @JsonProperty("Name") val name: String? = null,
    @JsonProperty("Summary") val summary: String? = null,
    @JsonProperty("Image") val image: String? = null,
    @JsonProperty("Type") val type: String? = null,
    @JsonProperty("Genres") val genres: String? = null,
    @JsonProperty("ReleaseDate") val releaseDate: String? = null,
    @JsonProperty("IMDBScore") val imdbScore: String? = null,
    @JsonProperty("Runtime") val runtime: String? = null,
    @JsonProperty("Backdrop") val backdrop: String? = null,
    @JsonProperty("Logo") val logo: String? = null
)

@JsonIgnoreProperties(ignoreUnknown = true)
data class MoviesResponse(
    @JsonProperty("movies") val movies: List<MovieItem>? = null
)

@JsonIgnoreProperties(ignoreUnknown = true)
data class MainPageResponse(
    @JsonProperty("first_alt") val firstAlt: List<MovieItem>? = null,
    @JsonProperty("second") val second: List<MovieItem>? = null,
    @JsonProperty("third") val third: List<MovieItem>? = null,
    @JsonProperty("fourth") val fourth: List<MovieItem>? = null,
    @JsonProperty("movies") val movies: List<MovieItem>? = null
)

@JsonIgnoreProperties(ignoreUnknown = true)
data class EpisodeItem(
    @JsonProperty("Episode") val episode: String? = null,
    @JsonProperty("Season") val season: String? = null,
    @JsonProperty("E_ID") val episodeId: String? = null,
    @JsonProperty("ID") val seriesId: String? = null,
    @JsonProperty("Summary") val summary: String? = null,
    @JsonProperty("IMDBScore") val imdbScore: String? = null,
    @JsonProperty("ReleaseDate") val releaseDate: String? = null,
    @JsonProperty("Image") val image: String? = null,
    @JsonProperty("Name") val name: String? = null,
    @JsonProperty("Backdrop") val backdrop: String? = null
)

@JsonIgnoreProperties(ignoreUnknown = true)
data class EpisodesResponse(
    @JsonProperty("episodes") val episodes: List<EpisodeItem>? = null
)

@JsonIgnoreProperties(ignoreUnknown = true)
data class StreamItem(
    @JsonProperty("name") val name: String? = null,
    @JsonProperty("Link") val link: String? = null,
    @JsonProperty("Provider") val provider: String? = null,
    @JsonProperty("MainProvider") val mainProvider: String? = null,
    @JsonProperty("isTurkish") val isTurkish: Any? = null,
    @JsonProperty("Backdrop") val backdrop: String? = null,
    @JsonProperty("Logo") val logo: String? = null
)

@JsonIgnoreProperties(ignoreUnknown = true)
data class StreamsResponse(
    @JsonProperty("links") val links: List<StreamItem>? = null
)

@JsonIgnoreProperties(ignoreUnknown = true)
data class IPTVLinkItem(
    @JsonProperty("ID") val id: Any? = null,
    @JsonProperty("Name") val name: String? = null,
    @JsonProperty("Link") val link: String? = null,
    @JsonProperty("Image") val image: String? = null,
    @JsonProperty("Logo") val logo: String? = null
)

@JsonIgnoreProperties(ignoreUnknown = true)
data class IPTVResponse(
    @JsonProperty("isIPTV") val isIPTV: Any? = null,
    @JsonProperty("links") val links: List<IPTVLinkItem>? = null,
    @JsonProperty("movies") val movies: List<IPTVLinkItem>? = null
)
