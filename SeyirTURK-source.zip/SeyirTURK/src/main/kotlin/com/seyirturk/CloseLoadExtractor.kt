package com.seyirturk

import android.util.Base64
import android.util.Log
import com.lagradost.cloudstream3.SubtitleFile
import com.lagradost.cloudstream3.app
import com.lagradost.cloudstream3.newSubtitleFile
import com.lagradost.cloudstream3.utils.ExtractorApi
import com.lagradost.cloudstream3.utils.ExtractorLink
import com.lagradost.cloudstream3.utils.ExtractorLinkType
import com.lagradost.cloudstream3.utils.Qualities
import com.lagradost.cloudstream3.utils.newExtractorLink
import com.lagradost.cloudstream3.utils.M3u8Helper
import com.lagradost.cloudstream3.network.CloudflareKiller

class CloseLoad : ExtractorApi() {
    private val cloudflareKiller by lazy { CloudflareKiller() }
    override val name = "CloseLoad"
    override val mainUrl = "https://closeload.filmmakinesi.to"
    override val requiresReferer = true

    override suspend fun getUrl(
        url: String,
        referer: String?,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ) {
        val userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36"
        val playerReferer = referer?.takeIf { it.startsWith("http", ignoreCase = true) } ?: "$mainUrl/"
        val headers2 = mapOf(
            "User-Agent" to userAgent,
            "Referer" to playerReferer,
            "Origin" to mainUrl
        )

        try {
            val response = app.get(url, referer = playerReferer, headers = headers2)
            val html = if (response.text.contains("Just a moment", true) ||
                response.text.contains("cf-chl", true)) {
                app.get(url, referer = playerReferer, headers = headers2,
                    interceptor = cloudflareKiller).text
            } else response.text

            val realUrl = FilmMakinesiPlayerCipher.resolve(html)
                ?: decryptNative(html)
                ?: findDeclaredMediaUrl(html)
                ?: findJsonLdMediaUrl(html)

            val playable = !realUrl.isNullOrBlank() && realUrl.startsWith("http", ignoreCase = true) &&
                runCatching {
                    app.get(realUrl, headers = mapOf("User-Agent" to userAgent, "Referer" to url))
                        .text.trimStart().startsWith("#EXTM3U")
                }.getOrDefault(false)
            if (playable && realUrl != null) {
                val streamHeaders = mapOf("Referer" to url, "Origin" to mainUrl,
                    "User-Agent" to userAgent)
                val variants = runCatching {
                    M3u8Helper.generateM3u8(name, realUrl, url, headers = streamHeaders)
                }.getOrDefault(emptyList())
                val qualityLinks = selectQualityVariants(variants)
                if (qualityLinks.isNotEmpty()) qualityLinks.forEach(callback)
                else callback(newExtractorLink(name, name, realUrl, ExtractorLinkType.M3U8) {
                    this.referer = url
                    this.headers = streamHeaders
                })
            } else {
                Log.e("Kekik_${this.name}", "CloseLoad URL deşifre edilemedi.")
            }

            processSubtitles(html, url, subtitleCallback)

        } catch (e: Exception) {
            Log.e("Kekik_${this.name}", "Hata: ${e.message}")
        }
    }

    private fun findDeclaredMediaUrl(html: String): String? {
        val mediaPattern = Regex(
            """(?:file|src|source|hls|url|contentUrl)\s*["']?\s*[:=]\s*["'](https?:\\?/\\?/[^"'\s<>]+?\.m3u8(?:\?[^"'\s<>]*)?)["']""",
            RegexOption.IGNORE_CASE
        )
        val raw = mediaPattern.find(html)?.groupValues?.get(1) ?: return null
        return raw.replace("\\/", "/").replace("\\u0026", "&")
    }

    private fun findJsonLdMediaUrl(html: String): String? {
        val raw = Regex(""""contentUrl"\s*:\s*"([^"]+)"""", RegexOption.IGNORE_CASE)
            .find(html)?.groupValues?.get(1) ?: return null
        val candidate = raw.replace("\\/", "/").replace(".txt", ".m3u8")
        return candidate.takeIf { it.startsWith("http", true) && it.contains(".m3u8", true) }
    }

    private fun decryptNative(html: String): String? {
        return try {
            val ahkMatch = Regex("""var\s+[a-zA-Z0-9_]+\s*=\s*["']([a-zA-Z0-9]{15,35})["']""").find(html)
            val uwkdMatch = Regex("""var\s+[a-zA-Z0-9_]+\s*=\s*["']([a-zA-Z]{2,8})["']""").find(html)
            val arrMatch = Regex("""\(\[((?:["'][^"']+["'],?\s*)+)\]\)""").find(html)

            if (ahkMatch == null || uwkdMatch == null || arrMatch == null) {
                Log.w("Kekik_${this.name}", "Regex eşleşmedi: ahk=${ahkMatch != null}, uwkd=${uwkdMatch != null}, arr=${arrMatch != null}")
                return null
            }

            val ahk = ahkMatch.groupValues[1]
            val uwkd = uwkdMatch.groupValues[1]
            val parts = arrMatch.groupValues[1].split(",").map {
                it.trim().replace("\"", "").replace("'", "").replace("\\/", "/")
            }

            var whm = parts.joinToString("")
            var qtvy = 0
            var pcn = 0
            for (i in 0 until ahk.length) {
                val c = ahk[i].code
                qtvy = (qtvy * 31 + c) % 251
                pcn = (pcn xor (c + i)) and 255
            }

            val tqinz = (qtvy + pcn) % 256
            val mwb = (qtvy % 13) + 3
            var cgu = ((qtvy * 256 + pcn) % 65521) + 1

            for (i in uwkd.length - 1 downTo 0) {
                val op = uwkd[i]
                when (op) {
                    'b' -> {
                        val pad = whm.length % 4
                        if (pad != 0) whm += "=".repeat(4 - pad)
                        whm = String(Base64.decode(whm, Base64.NO_WRAP), Charsets.ISO_8859_1)
                    }
                    'v' -> {
                        whm = whm.reversed()
                    }
                    else -> {
                        val qth = (26 - ((op.code - 64) % 26)) % 26
                        val sb = StringBuilder(whm.length)
                        for (ch in whm) {
                            val code = ch.code
                            if (code in 65..90) {
                                sb.append(((code - 65 + qth) % 26 + 65).toChar())
                            } else if (code in 97..122) {
                                sb.append(((code - 97 + qth) % 26 + 97).toChar())
                            } else {
                                sb.append(ch)
                            }
                        }
                        whm = sb.toString()
                    }
                }
            }

            val y1su9 = whm.length
            val uo75 = IntArray(y1su9)
            for (i in y1su9 - 1 downTo 1) {
                cgu = (cgu * 75 + 74) % 65537
                uo75[i] = cgu % (i + 1)
            }

            val a44f = whm.toCharArray()
            for (i in 1 until y1su9) {
                val canf = uo75[i]
                val mkuhn = a44f[i]
                a44f[i] = a44f[canf]
                a44f[canf] = mkuhn
            }
            whm = String(a44f)

            var nfn = tqinz
            val u32d8 = StringBuilder(whm.length)
            for (i in 0 until whm.length) {
                val e1b1j = whm[i].code
                nfn = (nfn + mwb) % 256
                u32d8.append((e1b1j xor nfn).toChar())
                nfn = (nfn + e1b1j) % 256
            }

            u32d8.toString().trim()
        } catch (e: Exception) {
            Log.e("Kekik_${this.name}", "Deşifre hatası: ${e.message}")
            null
        }
    }

    private suspend fun processSubtitles(html: String, playerUrl: String, subtitleCallback: (SubtitleFile) -> Unit) {
        try {
            val tracksMatch = """tracks\s*:\s*(\[.*?\])""".toRegex(RegexOption.DOT_MATCHES_ALL).find(html)
            tracksMatch?.groupValues?.get(1)?.let { tracksJson ->
                val trackPattern = """\{[^}]*\}""".toRegex()
                val fileRegex = """"file"\s*:\s*"([^"]+)"""".toRegex()
                val labelRegex = """"label"\s*:\s*"([^"]+)"""".toRegex()

                trackPattern.findAll(tracksJson).forEach { match ->
                    val block = match.value
                    val file = fileRegex.find(block)?.groupValues?.get(1)?.replace("\\/", "/")
                    val label = labelRegex.find(block)?.groupValues?.get(1) ?: "Altyazı"

                    if (!file.isNullOrBlank() && file.startsWith("http")) {
                        subtitleCallback.invoke(newSubtitleFile(label, file) {
                            headers = mapOf("Referer" to playerUrl, "Origin" to mainUrl)
                        })
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("Kekik_${this.name}", "Altyazı hatası: ${e.message}")
        }
    }
}

