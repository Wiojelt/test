package com.seyirturk

import android.net.Uri
import android.util.Base64
import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.AppUtils
import com.lagradost.cloudstream3.utils.ExtractorLink
import com.lagradost.cloudstream3.utils.ExtractorLinkType
import com.lagradost.cloudstream3.utils.Qualities
import com.lagradost.cloudstream3.utils.loadExtractor
import com.lagradost.cloudstream3.utils.newExtractorLink
import com.lagradost.cloudstream3.network.CloudflareKiller
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withTimeoutOrNull
import org.jsoup.Jsoup
import org.json.JSONObject
import org.json.JSONArray
import java.net.URLEncoder

class SeyirTURK : MainAPI() {
    private val cloudflareKiller by lazy { CloudflareKiller() }
    override var name = "SeyirTURK"
    override var mainUrl = "https://beytepemanav.tk"
    override var lang = "tr"
    override val hasMainPage = true
    override val supportedTypes = setOf(TvType.Movie, TvType.TvSeries, TvType.Live)

    private val userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    private val apiHeaders = mapOf(
        "User-Agent" to userAgent,
        "bety" to "jughead"
    )

    private var backendCache: String? = null

    private suspend fun getBackend(): String {
        backendCache?.let { return it }
        val rootCheckUrls = listOf(
            "https://seyirturk.net/rootcheck/android.php",
            "https://seyirturk.net/rootcheck/kodi.php"
        )
        for (rootUrl in rootCheckUrls) {
            try {
                val res = app.get(rootUrl, headers = mapOf("User-Agent" to userAgent)).text.trim()
                if (res.isNotBlank()) {
                    val reversed = res.reversed()
                    val decodedBytes = Base64.decode(reversed, Base64.DEFAULT)
                    val decodedUrl = String(decodedBytes, Charsets.UTF_8).trim()
                    val normalized = if (decodedUrl.endsWith("/")) decodedUrl else "$decodedUrl/"
                    if (normalized.startsWith("http")) {
                        backendCache = normalized
                        mainUrl = normalized.trimEnd('/')
                        return normalized
                    }
                }
            } catch (_: Exception) {}
        }
        val fallback = "https://beytepemanav.tk/"
        backendCache = fallback
        mainUrl = fallback.trimEnd('/')
        return fallback
    }

    override val mainPage: List<MainPageData> = mainPageOf(
        "sey/back/mainpage.php" to "Vizyondakiler / Yeni Filmler",
        "sey/back/show.php?type=genre&genre=Yerli" to "Yerli Filmler",
        "sey/back/show.php?type=genre&genre=TRDUB" to "Türkçe Dublaj Filmler",
        "sey/back/show.php?type=genre&genre=TRSUB" to "Türkçe Altyazılı Filmler",
        "sey/back/show.php?type=genre&p_type=TV&genre=Yerli" to "Yerli Diziler",
        "sey/back/show.php?type=genre&p_type=TV&genre=TRDUB" to "Yabancı Diziler (Dublaj)",
        "sey/back/show.php?type=genre&p_type=TV&genre=TRSUB" to "Yabancı Diziler (Altyazı)",
        "sey/kodi/iptv/premium.php" to "Canlı TV (Türkiye)",
        "iptv/volotv/online.php" to "Canlı TV (VoloTV)",
        "https://iptv-org.github.io/iptv/languages/tur.m3u" to "Canlı TV (Dünya)"
    )

    override suspend fun getMainPage(page: Int, request: MainPageRequest): HomePageResponse {
        val backend = getBackend()
        val url = if (request.data.startsWith("http")) {
            request.data
        } else {
            backend + request.data.trimStart('/')
        }

        val items = mutableListOf<SearchResponse>()
        try {
            val res = app.get(url, headers = apiHeaders).text
            if (res.startsWith("#EXTM3U") || url.endsWith(".m3u")) {
                items.addAll(parseM3U(res))
            } else if (request.data.contains("mainpage.php")) {
                val parsed = AppUtils.parseJson<MainPageResponse>(res)
                val allMovies = listOfNotNull(parsed.firstAlt, parsed.second, parsed.third,
                    parsed.fourth, parsed.movies).flatten().distinctBy { it.id }
                allMovies.forEach { movie ->
                    movie.toSearchResponse(TvType.Movie)?.let { items.add(it) }
                }
            } else if (res.contains("\"isIPTV\"") || url.contains("iptv")) {
                val parsed = AppUtils.parseJson<IPTVResponse>(res)
                val links = parsed.links ?: parsed.movies
                links?.forEach { link ->
                    link.toSearchResponse()?.let { items.add(it) }
                }
            } else {
                val parsed = AppUtils.parseJson<MoviesResponse>(res)
                val isTv = request.data.contains("p_type=TV")
                val tvType = if (isTv) TvType.TvSeries else TvType.Movie
                parsed.movies?.forEach { movie ->
                    movie.toSearchResponse(tvType)?.let { items.add(it) }
                }
            }
        } catch (_: Exception) {}

        val pageSize = 35
        val startIndex = (page - 1) * pageSize
        val pagedList = if (startIndex < items.size) {
            val endIndex = (startIndex + pageSize).coerceAtMost(items.size)
            items.subList(startIndex, endIndex)
        } else {
            emptyList()
        }

        val hasNext = (startIndex + pageSize) < items.size
        return newHomePageResponse(request.name, pagedList, hasNext)
    }

    override suspend fun search(query: String, page: Int): SearchResponseList = coroutineScope {
        val q = query.trim()
        if (q.isBlank()) return@coroutineScope newSearchResponseList(emptyList(), false)

        val backend = getBackend()
        val encoded = URLEncoder.encode(q, "UTF-8")

        val moviesDeferred = async {
            try {
                val url = "${backend}sey/back/search.php?name=$encoded"
                val res = app.get(url, headers = apiHeaders).text
                AppUtils.parseJson<MoviesResponse>(res).movies ?: emptyList()
            } catch (_: Exception) {
                emptyList()
            }
        }

        val seriesDeferred = async {
            try {
                val url = "${backend}sey/back/search.php?p_type=TV&name=$encoded"
                val res = app.get(url, headers = apiHeaders).text
                AppUtils.parseJson<MoviesResponse>(res).movies ?: emptyList()
            } catch (_: Exception) {
                emptyList()
            }
        }

        val results = mutableListOf<SearchResponse>()
        val movies = moviesDeferred.await()
        val series = seriesDeferred.await()

        movies.forEach { m ->
            m.toSearchResponse(TvType.Movie)?.let { results.add(it) }
        }
        series.forEach { s ->
            s.toSearchResponse(TvType.TvSeries)?.let { results.add(it) }
        }

        newSearchResponseList(results, false)
    }

    override suspend fun load(url: String): LoadResponse? {
        val uri = Uri.parse(url)

        if (url.contains("/live") || url.contains("live?")) {
            val name = uri.getQueryParameter("name") ?: "Canlı Yayın"
            val streamUrl = uri.getQueryParameter("url") ?: return null
            val poster = uri.getQueryParameter("poster")
            return newLiveStreamLoadResponse(name, url, streamUrl) {
                this.posterUrl = poster
            }
        }

        val backend = getBackend()

        if (url.contains("/movie") || url.contains("movie?")) {
            val id = uri.getQueryParameter("id") ?: return null
            val singleUrl = "${backend}sey/back/show.php?type=single&id=$id"
            val singleJson = app.get(singleUrl, headers = apiHeaders).text
            val movie = AppUtils.parseJson<MoviesResponse>(singleJson).movies?.firstOrNull()

            val title = movie?.name ?: uri.getQueryParameter("name") ?: "Film"
            val poster = movie?.image ?: uri.getQueryParameter("poster")
            val backdrop = movie?.backdrop ?: poster

            return newMovieLoadResponse(title, url, TvType.Movie, "movie:$id") {
                this.posterUrl = poster
                this.backgroundPosterUrl = backdrop
                this.plot = movie?.summary
                this.year = movie?.releaseDate?.take(4)?.toIntOrNull()
                movie?.imdbScore?.let { this.score = Score.from10(it) }
                this.tags = movie?.genres?.split(",")?.map { it.trim() }?.filter { it.isNotBlank() }
                this.duration = movie?.runtime?.toIntOrNull()
            }
        }

        if (url.contains("/series") || url.contains("series?")) {
            val id = uri.getQueryParameter("id") ?: return null
            val singleUrl = "${backend}sey/back/show.php?type=single&p_type=TV&id=$id"
            val singleJson = app.get(singleUrl, headers = apiHeaders).text
            val series = AppUtils.parseJson<MoviesResponse>(singleJson).movies?.firstOrNull()

            val epUrl = "${backend}sey/back/episodes.php?id=$id&isTv=1"
            val epJson = app.get(epUrl, headers = apiHeaders).text
            val epResponse = AppUtils.parseJson<EpisodesResponse>(epJson)

            val episodes = epResponse.episodes?.sortedWith(compareBy(
                { it.season?.toIntOrNull() ?: 1 }, { it.episode?.toIntOrNull() ?: 1 }
            ))?.mapNotNull { ep ->
                val epNum = ep.episode?.toIntOrNull() ?: 1
                val sNum = ep.season?.toIntOrNull() ?: 1
                newEpisode("series_ep:$id:$sNum:$epNum") {
                    this.name = "${ep.name?.trim().orEmpty().ifBlank { series?.name ?: "Dizi" }} - $epNum. Bölüm"
                    this.season = sNum
                    this.episode = epNum
                    this.posterUrl = ep.image
                    this.description = ep.summary
                }
            } ?: emptyList()

            val title = series?.name ?: uri.getQueryParameter("name") ?: "Dizi"
            val poster = series?.image ?: uri.getQueryParameter("poster")
            val backdrop = series?.backdrop ?: poster

            return newTvSeriesLoadResponse(title, url, TvType.TvSeries, episodes) {
                this.posterUrl = poster
                this.backgroundPosterUrl = backdrop
                this.plot = series?.summary
                this.year = series?.releaseDate?.take(4)?.toIntOrNull()
                series?.imdbScore?.let { this.score = Score.from10(it) }
                this.tags = series?.genres?.split(",")?.map { it.trim() }?.filter { it.isNotBlank() }
            }
        }

        return null
    }

    override suspend fun loadLinks(
        data: String,
        isCasting: Boolean,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        if (data.startsWith("http://") || data.startsWith("https://")) {
            return resolveDirectOrExtractor(data, name, subtitleCallback, callback)
        }

        val backend = getBackend()

        if (data.startsWith("movie:")) {
            val id = data.substringAfter("movie:")
            val streamsUrl = "${backend}sey/back/streams.php?id=$id"
            return fetchAndResolveStreams(streamsUrl, subtitleCallback, callback)
        }

        if (data.startsWith("series_ep:")) {
            val parts = data.split(":")
            val id = parts.getOrNull(1) ?: return false
            val season = parts.getOrNull(2) ?: "1"
            val episode = parts.getOrNull(3) ?: "1"
            val streamsUrl = "${backend}sey/back/streams.php?id=$id&isTv=1&e=$episode&s=$season"
            return fetchAndResolveStreams(streamsUrl, subtitleCallback, callback)
        }

        return false
    }

    private suspend fun fetchAndResolveStreams(
        url: String,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        try {
            val res = app.get(url, headers = apiHeaders).text
            val parsed = AppUtils.parseJson<StreamsResponse>(res)
            val streamLinks = parsed.links ?: return false

            // A single dead mirror must not hold the whole source list hostage.
            // Keep every candidate, but bound the number of active site requests.
            val semaphore = Semaphore(8)
            val callbackLock = Any()
            val emittedUrls = mutableSetOf<Pair<String, Int>>()
            var emitted = false
            fun reportLink(link: ExtractorLink, providerName: String) {
                val label = when {
                    link.source.equals("CloseLoad", true) -> "$providerName Close"
                    link.source.equals("Rapid FilmMakinesi", true) -> "$providerName Rapid"
                    link.name.contains("VIP", true) && !providerName.contains("VIP", true) -> "$providerName VIP"
                    else -> providerName
                }
                val cleanLink = ExtractorLink(
                    source = label,
                    name = label,
                    url = link.url,
                    referer = link.referer,
                    quality = link.quality,
                    headers = link.headers,
                    extractorData = link.extractorData,
                    type = link.type,
                    audioTracks = link.audioTracks
                )
                synchronized(callbackLock) {
                    if (emittedUrls.add(cleanLink.url to cleanLink.quality)) {
                        emitted = true
                        callback(cleanLink)
                    }
                }
            }
            coroutineScope {
                streamLinks.sortedBy { stream ->
                    val link = stream.link.orEmpty().lowercase()
                    when {
                        "setfilmizle." in link -> 0
                        "dizimom.wiki" in link || "canlidizi" in link || "ddizi." in link -> 1
                        "dizibal.org" in link -> 2
                        "webteizle." in link || "fullhdfilmizlesene." in link -> 3
                        "filmekseni." in link || "vidmoly." in link -> 4
                        else -> 5
                    }
                }.map { stream ->
                    async {
                        try {
                            val rawLink = stream.link?.trim().orEmpty()
                            if (rawLink.isBlank()) return@async
                            val fixedLink = when {
                                rawLink.startsWith("//") -> "https:$rawLink"
                                !rawLink.startsWith("http") -> "https://$rawLink"
                                else -> rawLink
                            }
                            val providerName = stream.provider ?: stream.mainProvider ?: name
                            semaphore.withPermit {
                                withTimeoutOrNull(20_000) {
                                    val hotlingerLinks = mutableListOf<ExtractorLink>()
                                    resolveDirectOrExtractor(fixedLink, providerName,
                                        { subtitle -> synchronized(callbackLock) { subtitleCallback(subtitle) } },
                                        { link ->
                                            if (link.source.equals("Hotlinger", true)) hotlingerLinks.add(link)
                                            else reportLink(link, providerName)
                                        }
                                    )
                                    for (link in hotlingerLinks) {
                                        val valid = runCatching {
                                            link.type == ExtractorLinkType.M3U8 &&
                                                app.get(link.url, headers = link.headers +
                                                    (if (link.referer.isNotBlank()) mapOf("Referer" to link.referer)
                                                     else emptyMap())).text.trimStart().startsWith("#EXTM3U")
                                        }.getOrDefault(false)
                                        if (valid) reportLink(link, providerName)
                                    }
                                }
                            }
                        } catch (e: CancellationException) {
                            throw e
                        } catch (_: Exception) {
                            // Another mirror may still produce a playable stream.
                        }
                    }
                }.awaitAll()
            }
            return emitted
        } catch (_: Exception) {
            return false
        }
    }

    private suspend fun resolveDirectOrExtractor(
        url: String,
        provider: String,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        try {
            if (url.contains("selcukflix.com/") || url.contains("sinefil")) {
                return resolveSinefil(url, provider, subtitleCallback, callback)
            }
            if (url.contains("canlidizi")) {
                return resolveCanliDizi(url, provider, callback)
            }
            if (url.contains("dizimom.wiki")) {
                return resolveDizimom(url, provider, subtitleCallback, callback)
            }
            if (url.contains("ddizi.")) {
                return resolveDDizi(url, provider, callback)
            }
            if (url.contains("setfilmizle.")) {
                return resolveSetFilm(url, provider, subtitleCallback, callback)
            }
            if (url.contains("hotlinger.com/") || url.contains("dplayer82.site/") ||
                url.contains("pichive.online/")) {
                return resolveHotlinger(url, provider, subtitleCallback, callback)
            }
            if (url.contains("webteizle.")) {
                val proxy = "${getBackend()}sey/kodi/proxies/webteizle.php?path=izle&url=" +
                    URLEncoder.encode(url, "UTF-8")
                val playerUrl = app.get(proxy, headers = apiHeaders).text.trim()
                if (playerUrl.startsWith("http") && playerUrl.contains("vidmoly")) {
                    return resolveVidmoly(playerUrl, url, provider, subtitleCallback, callback)
                }
                return false
            }
            if (url.contains("vidmoly.") || url.contains("vidmoly.net/")) {
                return resolveVidmoly(url, "", provider, subtitleCallback, callback)
            }
            if (url.contains("sinemaizle.org/film/")) {
                // Its public page currently exposes an advertisement MP4, not the film.
                return false
            }
            if (url.contains("kultfilmler.net/")) {
                val page = app.get(url, headers = mapOf("User-Agent" to userAgent)).document
                val player = page.select("iframe[src], iframe[data-src]").map { node ->
                    node.attr("data-src").ifBlank { node.attr("src") }
                }.firstOrNull { it.contains("vidpapi.xyz/video/") }
                if (player != null) {
                    val absolute = java.net.URI(url).resolve(player).toString()
                    return resolveVidpapi(absolute, url, provider, subtitleCallback, callback)
                }
                return false
            }
            if (url.contains("vidpapi.xyz/video/")) {
                return resolveVidpapi(url, "https://kultfilmler.net/", provider, subtitleCallback, callback)
            }
            if (url.contains("filmekseni.") || url.contains("hdfilmcehennemi")) {
                val response = app.get(url, headers = mapOf("User-Agent" to "Google"))
                val pageUrl = response.url.toString()
                val page = Jsoup.parse(response.text, pageUrl)
                val playerData = page.selectFirst("[data-video-player]")?.attr("x-data").orEmpty()
                val encodedJson = Regex("""JSON\.parse\('([^']+)'\)""")
                    .find(playerData)?.groupValues?.getOrNull(1).orEmpty()
                if (encodedJson.isNotBlank()) {
                    val playerGroups = JSONObject(encodedJson.replace("\\u0022", "\""))
                    var found = false
                    for (language in playerGroups.keys()) {
                        val sources = playerGroups.optJSONArray(language) ?: continue
                        for (index in 0 until sources.length()) {
                            val source = sources.optJSONObject(index) ?: continue
                            val template = runCatching {
                                String(Base64.decode(source.optString("template"), Base64.DEFAULT), Charsets.UTF_8)
                            }.getOrNull() ?: continue
                            val rawPlayer = Regex("""data-src=["']([^"']+)""")
                                .find(template)?.groupValues?.getOrNull(1) ?: continue
                            val relative = rawPlayer.replace("{url}", source.optString("link"))
                                .replace("{slug}", source.optString("slug"))
                            val player = java.net.URI(pageUrl).resolve(
                                if (relative.startsWith("//")) "https:$relative" else relative
                            ).toString()
                            if (runCatching {
                                resolveVidload(player, pageUrl,
                                    "$provider ${source.optString("service_name")}",
                                    subtitleCallback, callback)
                            }.getOrDefault(false)) found = true
                        }
                    }
                    if (found) return true
                }
            }
            if (url.contains("filmmakinesi.") && !url.contains("closeload.") && !url.contains("rapid.")) {
                val siteHeaders = mapOf(
                    "User-Agent" to "Google",
                    "Referer" to "https://filmmakinesi.to/"
                )
                val firstPage = runCatching { app.get(url, headers = siteHeaders).document }.getOrNull()
                val page = if (firstPage?.select(".video-parts [data-video_url], iframe[data-src]")?.isNotEmpty() == true)
                    firstPage else app.get(url, headers = siteHeaders, interceptor = cloudflareKiller).document
                val candidates = (page.select("iframe[src], iframe[data-src]").map { node ->
                    node.attr("data-src").ifBlank { node.attr("src") }
                } + page.select(".video-parts [data-video_url]").map { it.attr("data-video_url") })
                    .mapNotNull { raw -> runCatching { java.net.URI(url).resolve(raw).toString() }.getOrNull() }
                    .filter { it.startsWith("http") && !it.contains("youtube") && !it.contains("youtu.be") }
                    .distinct()
                var found = false
                for (player in candidates) {
                    runCatching {
                        val report: (ExtractorLink) -> Unit = { link -> found = true; callback(link) }
                        when {
                            player.contains("closeload.filmmakinesi") ->
                                CloseLoad().getUrl(player, url, subtitleCallback, report)
                            player.contains("rapid.filmmakinesi") ->
                                RapidFilmMakinesi().getUrl(player, url, subtitleCallback, report)
                            else -> loadExtractor(player, url, subtitleCallback, report)
                        }
                    }
                }
                return found
            }
            if (url.contains("fullhdfilmizle.now/film/")) {
                val site = java.net.URI(url).let { "${it.scheme}://${it.host}" }
                val page = app.get(url, headers = mapOf("User-Agent" to userAgent)).document
                val face = page.selectFirst(".vp-face[data-src-type][data-src-id][data-src-token]")
                if (face != null) {
                    val requestHeaders = mapOf("User-Agent" to userAgent,
                        "X-Requested-With" to "XMLHttpRequest", "Referer" to url)
                    val token = JSONObject(app.get("$site/api/token", headers = requestHeaders).text)
                        .optString("token")
                    if (token.isNotBlank()) {
                        val response = JSONObject(app.post("$site/api/view", headers = requestHeaders,
                            data = mapOf("t" to face.attr("data-src-type"),
                                "i" to face.attr("data-src-id"),
                                "k" to face.attr("data-src-token"),
                                "csrf_token" to token)).text)
                        val embed = response.optString("embed")
                        if (response.optBoolean("ok") && embed.startsWith("http")) {
                            var found = false
                            loadExtractor(embed, url, subtitleCallback) { link ->
                                found = true
                                callback(link)
                            }
                            if (found) return true
                        }
                    }
                }
            }
            if (url.contains("dizibal.org/movie/") || url.contains("dizibal.org/series/")) {
                val watchUrl = when {
                    url.contains("dizibal.org/series/") -> url.substringBefore('?')
                    url.substringBefore('?').endsWith("/izle") -> url.substringBefore('?')
                    else -> url.substringBefore('?').trimEnd('/') + "/izle"
                }
                val watch = app.get(watchUrl, headers = mapOf("User-Agent" to userAgent)).text
                val document = Jsoup.parse(watch, watchUrl)
                val slug = document.selectFirst("[data-pv]")?.attr("data-pv").orEmpty()
                val scriptUrl = document.selectFirst("script[src*='core.js']")?.attr("abs:src").orEmpty()
                if (slug.isNotBlank() && scriptUrl.isNotBlank()) {
                    val playerUrl = java.net.URI(scriptUrl).resolve("s.php?s=${URLEncoder.encode(slug, "UTF-8")}").toString()
                    val playerHtml = app.get(playerUrl, headers = mapOf(
                        "User-Agent" to userAgent, "Referer" to watchUrl
                    )).text
                    val playerJson = Regex("""window\.__PLAYER__\s*=\s*(\{.*?});""", RegexOption.DOT_MATCHES_ALL)
                        .find(playerHtml)?.groupValues?.getOrNull(1)
                    if (playerJson != null) {
                        val player = JSONObject(playerJson)
                        val streamUrl = player.optString("stream")
                        if (streamUrl.startsWith("https://") &&
                            java.net.URI(streamUrl).path.endsWith("/api/stream.php")) {
                            val streamHeaders = mapOf("User-Agent" to userAgent, "Referer" to watchUrl)
                                callback(newExtractorLink(provider, provider, streamUrl, ExtractorLinkType.M3U8) {
                                    referer = watchUrl
                                    headers = streamHeaders
                                })
                                val subs = player.optJSONArray("subs")
                                if (subs != null) for (index in 0 until subs.length()) {
                                    val sub = subs.optJSONObject(index) ?: continue
                                    val subUrl = sub.optString("src")
                                    if (subUrl.startsWith("http")) {
                                        subtitleCallback(SubtitleFile(sub.optString("label").ifBlank { "Türkçe" }, subUrl))
                                    }
                                }
                                return true
                        }
                    }
                }
            }
            if (url.contains("filmmodu.") && url.contains("get-source")) {
                val payload = JSONObject(app.get(url.substringBefore('#'), headers = mapOf("User-Agent" to userAgent)).text)
                val sources = payload.optJSONArray("sources") ?: return false
                val fixedPlaylists = JSONArray()
                for (index in 0 until sources.length()) {
                    val source = sources.optJSONObject(index) ?: continue
                    val media = source.optString("src").replace("\\/", "/")
                    val height = source.optString("res").toIntOrNull()
                    if (!media.startsWith("https://") || !media.substringBefore('?').endsWith(".m3u8") ||
                        height == null || height < 144 || height > 2160) continue
                    fixedPlaylists.put(JSONObject().put("height", height).put("url", media))
                }
                if (fixedPlaylists.length() > 0) {
                    val masterUrl = if (fixedPlaylists.length() == 1) {
                        fixedPlaylists.getJSONObject(0).getString("url")
                    } else {
                        val encoded = Base64.encodeToString(fixedPlaylists.toString().toByteArray(Charsets.UTF_8),
                            Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
                        "https://seyirturk-hls-master.hdf-worker.workers.dev/master.m3u8?q=$encoded"
                    }
                    callback(newExtractorLink(provider, provider, masterUrl, ExtractorLinkType.M3U8) {
                        referer = "https://www.filmmodu.one/"
                        headers = mapOf("User-Agent" to userAgent, "Referer" to "https://www.filmmodu.one/")
                    })
                }
                val subtitle = payload.optString("subtitle")
                if (subtitle.isNotBlank()) {
                    val absolute = runCatching { java.net.URI(url).resolve(subtitle).toString() }.getOrNull()
                    if (absolute != null) subtitleCallback(SubtitleFile("Türkçe", absolute))
                }
                return fixedPlaylists.length() > 0
            }
            val path = runCatching { java.net.URI(url).path.lowercase() }.getOrDefault("")
            if (path.endsWith(".m3u8")) {
                callback.invoke(
                    ExtractorLink(
                        source = provider,
                        name = provider,
                        url = url,
                        referer = url,
                        quality = Qualities.Unknown.value,
                        type = ExtractorLinkType.M3U8
                    )
                )
                return true
            }

            if (path.endsWith(".mp4") && !url.contains("/reklam/", true) &&
                !url.contains("trailer", true) && !url.contains("vast", true)) {
                callback.invoke(
                    ExtractorLink(
                        source = provider,
                        name = provider,
                        url = url,
                        referer = url,
                        quality = Qualities.Unknown.value,
                        type = ExtractorLinkType.VIDEO
                    )
                )
                return true
            }

            val extracted = runCatching {
                loadExtractor(url, subtitleCallback, callback)
            }.getOrDefault(false)

            if (extracted) return true

            // If direct extractor did not resolve, parse HTML page for iframes / video tags
            val pageHtml = app.get(url, headers = mapOf("User-Agent" to userAgent)).text
            val doc = Jsoup.parse(pageHtml, url)

            var resolvedHtml = false
            doc.select("iframe[src], iframe[data-src], [data-video_url], [data-embed]").forEach { iframe ->
                val raw = iframe.attr("src").ifBlank { iframe.attr("data-src") }
                    .ifBlank { iframe.attr("data-video_url") }.ifBlank { iframe.attr("data-embed") }
                val src = runCatching { java.net.URI(url).resolve(raw).toString() }.getOrDefault("")
                if (src.isNotBlank() && !src.contains("google") && !src.contains("facebook") &&
                    !src.contains("youtube") && !src.startsWith("about:")) {
                    val res = runCatching {
                        loadExtractor(src, url, subtitleCallback, callback)
                    }.getOrDefault(false)
                    if (res) resolvedHtml = true
                }
            }

            // HTML5/JWPlayer source URLs are frequently stored in scripts rather than tags.
            val scriptMedia = Regex("""(?:file|src)\s*[:=]\s*["'](https?[^"']+)["']""", RegexOption.IGNORE_CASE)
                .findAll(pageHtml).map { it.groupValues[1].replace("\\/", "/") }
                .filter { it.contains(".m3u8", true) || it.contains(".mp4", true) }
                .filterNot { it.contains("/reklam/", true) || it.contains("trailer", true) ||
                    it.contains("banner", true) || it.contains("vast", true) }
                .distinct().take(12)
            scriptMedia.forEach { media ->
                callback(newExtractorLink(provider, provider, media,
                    if (media.contains(".m3u8", true)) ExtractorLinkType.M3U8 else ExtractorLinkType.VIDEO) {
                    referer = url
                    quality = Qualities.Unknown.value
                })
                resolvedHtml = true
            }

            doc.select("video source").forEach { source ->
                val src = source.attr("abs:src")
                if (src.isNotBlank()) {
                    val type = if (src.lowercase().contains(".m3u8")) ExtractorLinkType.M3U8 else ExtractorLinkType.VIDEO
                    callback.invoke(
                        ExtractorLink(
                            source = provider,
                            name = provider,
                            url = src,
                            referer = url,
                            quality = Qualities.Unknown.value,
                            type = type
                        )
                    )
                    resolvedHtml = true
                }
            }

            return resolvedHtml
        } catch (_: Exception) {
            return false
        }
    }

    private suspend fun resolveSinefil(
        url: String,
        provider: String,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val html = app.get(url.substringBefore('#'), headers = mapOf("User-Agent" to userAgent)).text
        val secureData = Jsoup.parse(html).selectFirst("#__NEXT_DATA__")?.data()
            ?.let { JSONObject(it).optJSONObject("props")?.optJSONObject("pageProps")?.optString("secureData") }
            .orEmpty()
        if (secureData.isBlank()) return false
        val decoded = JSONObject(app.post(
            "${getBackend()}sey/back/v2/parser/dizilla.php",
            headers = apiHeaders,
            data = mapOf("v1" to secureData)
        ).text)
        val related = decoded.optJSONObject("RelatedResults")
            ?: decoded.optJSONObject("content")?.optJSONObject("result")
                ?.optJSONObject("RelatedResults") ?: return false
        var found = false
        for (key in related.keys()) {
            if (!key.contains("Sources", true)) continue
            val results = related.optJSONObject(key)?.optJSONArray("result") ?: continue
            for (index in 0 until results.length()) {
                val item = results.optJSONObject(index) ?: continue
                val sourceHtml = item.optString("source_content")
                val iframe = Jsoup.parse(sourceHtml, url).selectFirst("iframe[src]")?.attr("abs:src")
                    ?: continue
                val language = item.optString("language_name")
                if (resolveDirectOrExtractor(iframe, "$provider ${item.optString("source_name")} $language",
                        subtitleCallback, callback)) found = true
            }
        }
        return found
    }

    private suspend fun resolveCanliDizi(
        url: String,
        provider: String,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val page = app.get(url, headers = mapOf("User-Agent" to userAgent)).document
        val player = page.select("iframe[src], iframe[data-wpfc-original-src]")
            .map { it.attr("data-wpfc-original-src").ifBlank { it.attr("src") } }
            .firstOrNull { it.contains("fireplayer/video/") || it.contains("hlszone.com/video/") }
            ?: return false
        val playerUrl = java.net.URI(url).resolve(player).toString()
        return resolvePostVideoPlayer(url, playerUrl, provider, callback)
    }

    private suspend fun resolveDizimom(
        url: String,
        provider: String,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val page = app.get(url, headers = mapOf("User-Agent" to userAgent)).document
        val players = page.select("iframe[src]").map { it.attr("abs:src") }
            .filter { it.contains("/video/") && !it.contains("video_onu") }.distinct()
        var found = false
        for (player in players) {
            val resolved = if (player.contains("hdplayersystem") || player.contains("hlszone") ||
                player.contains("peacemakerst.com/tv/video/"))
                resolvePostVideoPlayer(url, player, provider, callback)
            else resolveDirectOrExtractor(player, provider, subtitleCallback, callback)
            if (resolved) found = true
        }
        return found
    }

    private suspend fun resolvePostVideoPlayer(
        pageUrl: String,
        playerUrl: String,
        provider: String,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val hash = java.net.URI(playerUrl).path.substringAfterLast('/')
        val response = JSONObject(app.post("$playerUrl?do=getVideo", headers = mapOf(
            "User-Agent" to userAgent,
            "Referer" to pageUrl,
            "X-Requested-With" to "XMLHttpRequest"
        ), data = mapOf("hash" to hash, "r" to java.net.URI(pageUrl).let { "${it.scheme}://${it.host}" },
            "s" to "")).text)
        val sources = response.optJSONArray("videoSources")
        var found = false
        val candidates = mutableListOf<String>()
        if (sources != null) for (index in 0 until sources.length()) {
            candidates.add(sources.optJSONObject(index)?.optString("file").orEmpty())
        }
        if (candidates.isEmpty()) {
            candidates.add(response.optString("securedLink").ifBlank { response.optString("videoSource") })
        }
        for (media in candidates.distinct()) {
            if (!media.startsWith("https://")) continue
            val type = if (media.contains(".m3u8", true)) ExtractorLinkType.M3U8
                else ExtractorLinkType.VIDEO
            if (type == ExtractorLinkType.M3U8) {
                val valid = runCatching { app.get(media, headers = mapOf(
                    "User-Agent" to userAgent, "Referer" to playerUrl)).text
                    .trimStart().startsWith("#EXTM3U") }.getOrDefault(false)
                if (!valid) continue
            }
            callback(newExtractorLink(provider, provider, media, type) {
                referer = playerUrl
                headers = mapOf("User-Agent" to userAgent, "Referer" to playerUrl)
            })
            found = true
        }
        return found
    }

    private suspend fun resolveSetFilm(
        url: String,
        provider: String,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val pageUrl = url.substringBefore('?')
        val html = app.get(pageUrl, headers = mapOf("User-Agent" to userAgent)).text
        val nonce = Regex("""nonces:\s*\{video:\s*["']([^"']+)""")
            .find(html)?.groupValues?.getOrNull(1) ?: return false
        val doc = Jsoup.parse(html, pageUrl)
        val postId = doc.selectFirst("#stfPlayer[data-post-id]")?.attr("data-post-id")
            ?: return false
        val site = java.net.URI(pageUrl).let { "${it.scheme}://${it.host}" }
        val buttons = doc.select("#stfPlayer .src-tab[data-player-name]")
        var found = false
        for (button in buttons) {
            val response = runCatching { JSONObject(app.post("$site/wp-admin/admin-ajax.php",
                headers = mapOf("User-Agent" to userAgent, "Referer" to pageUrl,
                    "X-Requested-With" to "XMLHttpRequest"),
                data = mapOf("action" to "get_video_url", "nonce" to nonce,
                    "post_id" to postId, "player_name" to button.attr("data-player-name"),
                    "part_key" to button.attr("data-part-key"))).text) }.getOrNull() ?: continue
            val bridge = response.optJSONObject("data")?.optJSONObject("stream")?.optString("url")
                .orEmpty()
            if (!bridge.startsWith("https://")) continue
            val bridgeHtml = runCatching { app.get(bridge, headers = mapOf(
                "User-Agent" to userAgent, "Referer" to pageUrl)).text }.getOrNull() ?: continue
            val encoded = Regex("""SPG\.cerceve\("b2","([^"]+)","([^"]+)"\)""")
                .find(bridgeHtml)?.groupValues ?: continue
            val encrypted = runCatching { Base64.decode(encoded[1].replace("\\/", "/"), Base64.DEFAULT) }
                .getOrNull() ?: continue
            val key = runCatching { Base64.decode(encoded[2].replace("\\/", "/"), Base64.DEFAULT) }
                .getOrNull() ?: continue
            if (key.isEmpty()) continue
            val playerUrl = encrypted.indices.map { (encrypted[it].toInt() xor
                key[it % key.size].toInt()).toByte() }.toByteArray().toString(Charsets.UTF_8)
            if (!playerUrl.startsWith("https://")) continue
            val playerHtml = runCatching { app.get(playerUrl, headers = mapOf(
                "User-Agent" to userAgent, "Referer" to bridge)).text }.getOrNull() ?: continue
            val rawManifest = Regex("""window\.STF_KOPRU\s*=\s*\{\s*src:\s*["']([^"']+)""")
                .find(playerHtml)?.groupValues?.getOrNull(1) ?: continue
            val manifest = runCatching { java.net.URI(playerUrl).resolve(rawManifest).toString() }
                .getOrNull() ?: continue
            val headers = mapOf("User-Agent" to userAgent, "Referer" to playerUrl)
            val isHls = runCatching { app.get(manifest, headers = headers).text
                .trimStart().startsWith("#EXTM3U") }.getOrDefault(false)
            if (!isHls) continue
            callback(newExtractorLink(provider, provider, manifest, ExtractorLinkType.M3U8) {
                referer = playerUrl
                this.headers = headers
            })
            found = true
            Regex("""["']file["']\s*:\s*["']([^"']+\.(?:vtt|srt)[^"']*)["']""",
                RegexOption.IGNORE_CASE).findAll(playerHtml).forEach { match ->
                subtitleCallback(SubtitleFile("Türkçe", match.groupValues[1]))
            }
        }
        return found
    }

    private suspend fun resolveDDizi(
        url: String,
        provider: String,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val page = app.get(url, headers = mapOf("User-Agent" to userAgent)).document
        val player = page.selectFirst("iframe[src*='/player/oynat/']")?.attr("abs:src")
            ?: return false
        val html = app.get(player, headers = mapOf("User-Agent" to userAgent, "Referer" to url)).text
        val media = Regex("""file\s*:\s*["'](https?[^"']+\.(?:m3u8|mp4)[^"']*)["']""",
            RegexOption.IGNORE_CASE).find(html)?.groupValues?.getOrNull(1) ?: return false
        val type = if (media.contains(".m3u8", true)) ExtractorLinkType.M3U8
            else ExtractorLinkType.VIDEO
        callback(newExtractorLink(provider, provider, media, type) {
            referer = player
            headers = mapOf("User-Agent" to userAgent, "Referer" to player)
        })
        return true
    }

    private suspend fun resolveHotlinger(
        url: String,
        provider: String,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val playerUrls = listOf(url.substringBefore("?l="),
            url.substringBefore("?l=").replace("sn.hotlinger.com", "sn.dplayer82.site"))
            .distinct()
        for (playerUrl in playerUrls) {
            val site = java.net.URI(playerUrl).let { "${it.scheme}://${it.host}" }
            val headers = mapOf("User-Agent" to userAgent, "Referer" to site)
            val firstHtml = runCatching { app.get(playerUrl, headers = headers).text }.getOrNull()
            val html = if (firstHtml?.contains("window.openPlayer(") == true) firstHtml
                else runCatching { app.get(playerUrl, headers = headers,
                    interceptor = cloudflareKiller).text }.getOrNull() ?: continue
            val playerId = Regex("""window\.openPlayer\(\s*['"]([^'"]+)""")
                .find(html)?.groupValues?.getOrNull(1) ?: continue
            val sourceJson = runCatching { app.get("$site/source2.php?v=$playerId",
                headers = headers).text }.getOrNull() ?: continue
            val playlist = runCatching { JSONObject(sourceJson).optJSONArray("playlist") }.getOrNull()
            var found = false
            val candidates = mutableListOf<String>()
            if (playlist != null) for (index in 0 until playlist.length()) {
                val sources = playlist.optJSONObject(index)?.optJSONArray("sources") ?: continue
                for (sourceIndex in 0 until sources.length()) {
                    candidates.add(sources.optJSONObject(sourceIndex)?.optString("file").orEmpty())
                }
            }
            if (candidates.isEmpty()) {
                Regex("""["']file["']\s*:\s*["']([^"']+)""")
                    .findAll(sourceJson).forEach { candidates.add(it.groupValues[1].replace("\\/", "/")) }
            }
            for (rawMedia in candidates.distinct()) {
                    val media = if (rawMedia.contains("hotlinger") || rawMedia.contains("dplayer82.site"))
                        rawMedia.replace("m.php", "master.m3u8") else rawMedia
                    if (!media.startsWith("http")) continue
                    val type = if (media.contains(".m3u8", true)) ExtractorLinkType.M3U8
                        else ExtractorLinkType.VIDEO
                    callback(newExtractorLink(provider, provider, media, type) {
                        referer = playerUrl
                        this.headers = mapOf("User-Agent" to userAgent, "Referer" to playerUrl)
                    })
                    found = true
            }
            Regex("""["']file["']\s*:\s*["']([^"']+\.(?:vtt|srt)[^"']*)["']""",
                RegexOption.IGNORE_CASE).findAll(html).forEach { match ->
                val subtitle = runCatching { java.net.URI(playerUrl).resolve(match.groupValues[1]).toString() }
                    .getOrNull()
                if (subtitle != null) subtitleCallback(SubtitleFile("Türkçe", subtitle))
            }
            if (found) return true
        }
        return false
    }

    private suspend fun resolveVidpapi(
        playerUrl: String,
        pageReferer: String,
        provider: String,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val id = java.net.URI(playerUrl).path.substringAfterLast('/').trim()
        if (!id.matches(Regex("[a-fA-F0-9]{32}"))) return false
        val playerHeaders = mapOf("User-Agent" to userAgent, "Referer" to pageReferer)
        val html = app.get(playerUrl, headers = playerHeaders).text
        val apiUrl = "https://vidpapi.xyz/player/index.php?data=$id&do=getVideo"
        val payload = JSONObject(app.post(apiUrl, headers = mapOf(
            "User-Agent" to userAgent,
            "Referer" to playerUrl,
            "X-Requested-With" to "XMLHttpRequest"
        ), data = mapOf("hash" to id, "r" to pageReferer)).text)
        val media = payload.optString("securedLink")
        if (!media.startsWith("https://")) return false
        val streamHeaders = mapOf("User-Agent" to userAgent, "Referer" to playerUrl)
        val manifest = runCatching { app.get(media, headers = streamHeaders).text }.getOrNull()
        if (manifest?.trimStart()?.startsWith("#EXTM3U") != true) return false
        callback(newExtractorLink(provider, provider, media, ExtractorLinkType.M3U8) {
            referer = playerUrl
            headers = streamHeaders
        })
        Regex("""playerjsSubtitle\s*=\s*["']\[([^]]+)](https?[^"']+)""")
            .find(html)?.let { match ->
                subtitleCallback(SubtitleFile(match.groupValues[1], match.groupValues[2]))
            }
        return true
    }

    private suspend fun resolveVidload(
        playerUrl: String,
        pageReferer: String,
        provider: String,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val html = app.get(playerUrl, headers = mapOf(
            "User-Agent" to "Google", "Referer" to pageReferer
        )).text
        val media = Regex("""file\s*:\s*["'](https?[^"']+\.m3u8[^"']*)""")
            .find(html)?.groupValues?.getOrNull(1)?.replace("\\/", "/") ?: return false
        val streamHeaders = mapOf("User-Agent" to userAgent, "Referer" to playerUrl)
        val playlist = runCatching { app.get(media, headers = streamHeaders).text }.getOrNull()
        if (playlist?.trimStart()?.startsWith("#EXTM3U") != true) return false
        callback(newExtractorLink(provider, provider, media, ExtractorLinkType.M3U8) {
            referer = playerUrl
            headers = streamHeaders
        })
        val trackJson = Regex("""var\s+subtitleTracks\s*=\s*(\[.*?]);""", RegexOption.DOT_MATCHES_ALL)
            .find(html)?.groupValues?.getOrNull(1)
        if (trackJson != null) {
            val tracks = runCatching { JSONArray(trackJson) }.getOrNull()
            if (tracks != null) for (index in 0 until tracks.length()) {
                val track = tracks.optJSONObject(index) ?: continue
                val subtitleUrl = track.optString("file")
                if (subtitleUrl.startsWith("http")) {
                    subtitleCallback(SubtitleFile(track.optString("label").ifBlank { "Altyazı" }, subtitleUrl))
                }
            }
        }
        return true
    }

    private suspend fun resolveVidmoly(
        playerUrl: String,
        pageReferer: String,
        provider: String,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val headers = mapOf("User-Agent" to userAgent,
            "Referer" to pageReferer.ifBlank { "https://vidmoly.net/" })
        val html = app.get(playerUrl, headers = headers).text
        val media = Regex("""sources\s*:\s*\[\s*\{\s*file\s*:\s*['"]([^'"]+)""")
            .find(html)?.groupValues?.getOrNull(1)?.replace("\\/", "/") ?: return false
        if (!media.startsWith("http")) return false
        val streamHeaders = mapOf("User-Agent" to userAgent, "Referer" to playerUrl)
        val playlist = runCatching { app.get(media, headers = streamHeaders).text }.getOrNull()
        if (playlist?.trimStart()?.startsWith("#EXTM3U") != true) return false
        callback(newExtractorLink(provider, provider, media, ExtractorLinkType.M3U8) {
            referer = playerUrl
            this.headers = streamHeaders
        })
        // Vidmoly may expose captions beside the media configuration.
        Regex("""\{[^{}]*file\s*:\s*['"]([^'"]+\.vtt[^'"]*)['"][^{}]*label\s*:\s*['"]([^'"]+)['"][^{}]*}""")
            .findAll(html).forEach { track ->
                val subtitle = runCatching {
                    java.net.URI(playerUrl).resolve(track.groupValues[1]).toString()
                }.getOrNull()
                if (subtitle != null) subtitleCallback(SubtitleFile(track.groupValues[2], subtitle))
            }
        return true
    }

    private fun parseM3U(body: String): List<SearchResponse> {
        val list = mutableListOf<SearchResponse>()
        var name: String? = null
        var logo: String? = null

        val logoRegex = Regex("""tvg-logo="([^"]*)"""")

        body.lineSequence().forEach { line ->
            val trimmed = line.trim()
            if (trimmed.startsWith("#EXTINF")) {
                name = trimmed.substringAfterLast(',').trim().ifBlank { null }
                logo = logoRegex.find(trimmed)?.groupValues?.getOrNull(1)?.trim()?.ifBlank { null }
            } else if (trimmed.startsWith("http")) {
                val channelName = name ?: trimmed
                val loadUrl = "https://seyirturk.net/v/live?name=${URLEncoder.encode(channelName, "UTF-8")}&url=${URLEncoder.encode(trimmed, "UTF-8")}" +
                        (if (logo != null) "&poster=${URLEncoder.encode(logo, "UTF-8")}" else "")
                val resp = newLiveSearchResponse(channelName, loadUrl, TvType.Live) {
                    this.posterUrl = logo
                }
                list.add(resp)
                name = null
                logo = null
            }
        }
        return list
    }

    private fun MovieItem.toSearchResponse(tvType: TvType): SearchResponse? {
        val itemId = id ?: return null
        val title = name?.trim() ?: "İçerik"
        val poster = image
        val host = if (tvType == TvType.TvSeries) "series" else "movie"
        val loadUrl = "https://seyirturk.net/v/$host?id=$itemId&name=${URLEncoder.encode(title, "UTF-8")}" +
                (if (poster != null) "&poster=${URLEncoder.encode(poster, "UTF-8")}" else "")

        return if (tvType == TvType.TvSeries) {
            newTvSeriesSearchResponse(title, loadUrl, TvType.TvSeries) {
                this.posterUrl = poster
            }
        } else {
            newMovieSearchResponse(title, loadUrl, TvType.Movie) {
                this.posterUrl = poster
            }
        }
    }

    private fun IPTVLinkItem.toSearchResponse(): SearchResponse? {
        val streamUrl = link?.trim() ?: return null
        val title = name?.trim() ?: "Canlı Kanal"
        val poster = image ?: logo
        val loadUrl = "https://seyirturk.net/v/live?name=${URLEncoder.encode(title, "UTF-8")}&url=${URLEncoder.encode(streamUrl, "UTF-8")}" +
                (if (poster != null) "&poster=${URLEncoder.encode(poster, "UTF-8")}" else "")

        return newLiveSearchResponse(title, loadUrl, TvType.Live) {
            this.posterUrl = poster
        }
    }
}
