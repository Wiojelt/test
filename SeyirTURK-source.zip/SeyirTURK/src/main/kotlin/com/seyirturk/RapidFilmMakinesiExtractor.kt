package com.seyirturk

import com.lagradost.cloudstream3.SubtitleFile
import com.lagradost.cloudstream3.app
import com.lagradost.cloudstream3.newSubtitleFile
import com.lagradost.cloudstream3.utils.ExtractorApi
import com.lagradost.cloudstream3.utils.ExtractorLink
import com.lagradost.cloudstream3.utils.ExtractorLinkType
import com.lagradost.cloudstream3.utils.Qualities
import com.lagradost.cloudstream3.utils.newExtractorLink
import com.lagradost.cloudstream3.utils.M3u8Helper
import com.lagradost.cloudstream3.network.CloudflareKiller
import org.json.JSONArray
import java.net.URI

class RapidFilmMakinesi : ExtractorApi() {
    private val cloudflareKiller by lazy { CloudflareKiller() }
    override val name = "Rapid FilmMakinesi"
    override val mainUrl = "https://rapid.filmmakinesi.to"
    override val requiresReferer = true

    override suspend fun getUrl(
        url: String,
        referer: String?,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ) {
        val userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36"
        val headers = mapOf("User-Agent" to userAgent, "Referer" to (referer ?: "https://filmmakinesi.to/"))
        val initial = app.get(url, headers = headers).text
        val html = if (initial.contains("Just a moment", true) || initial.contains("cf-chl", true))
            app.get(url, headers = headers, interceptor = cloudflareKiller).text else initial
        val media = FilmMakinesiPlayerCipher.resolve(html)
        if (media != null && runCatching {
                app.get(media, headers = mapOf("User-Agent" to userAgent, "Referer" to url))
                    .text.trimStart().startsWith("#EXTM3U")
            }.getOrDefault(false)) {
            val streamHeaders = mapOf("User-Agent" to userAgent, "Referer" to url)
            val variants = runCatching {
                M3u8Helper.generateM3u8(name, media, url, headers = streamHeaders)
            }.getOrDefault(emptyList())
            val qualityLinks = selectQualityVariants(variants)
            if (qualityLinks.isNotEmpty()) qualityLinks.forEach(callback)
            else callback(newExtractorLink(name, name, media, ExtractorLinkType.M3U8) {
                this.referer = url
                this.headers = streamHeaders
            })
        }

        val tracks = Regex("""tracks\s*:\s*(\[[^]]*])""").find(html)?.groupValues?.get(1)
        val array = runCatching { JSONArray(tracks) }.getOrNull() ?: return
        for (index in 0 until array.length()) {
            val track = array.optJSONObject(index) ?: continue
            val path = track.optString("file")
            if (path.isBlank()) continue
            val label = track.optString("label").ifBlank { "Altyazı" }
            val language = track.optString("language")
            if (language != "tr" && language != "forced" && !label.contains("Türk", true)) continue
            val subtitle = runCatching { URI(url).resolve(path).toString() }.getOrNull() ?: continue
            subtitleCallback(newSubtitleFile(if (language == "forced") "Türkçe Zorunlu" else "Türkçe", subtitle) {
                this.headers = mapOf("User-Agent" to userAgent, "Referer" to url)
            })
        }
    }
}

